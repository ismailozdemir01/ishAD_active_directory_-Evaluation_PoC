# ishAD Evaluation Test Matrix

| ID | Test | Expected |
|---|---|---|
| AD-01 | Connect to LDAPS | Connection succeeds |
| AD-02 | Enumerate domain/OU | Live objects appear |
| AD-03 | Create test object | Create event detected |
| AD-04 | Modify test object | Modify event detected |
| AD-05 | Delete test object | Deletion/reconciliation detected |
| RISK-01 | Privileged-group change | High/Critical risk |
| RISK-02 | Low-risk change | Low/Medium classification |
| APP-01 | High-risk change | Approval required |
| APP-02 | Conflict before approval | Conflict state |
| RB-01 | Approved test rollback | Rollback succeeds |
| RB-02 | Delete rollback | No guessed undelete |
| DET-01 | Suspicious SPN/delegation | Detection signal |
| ACL-01 | Risky ACL | Exposure finding |
| NET-01 | LDAP/Kerberos/SMB endpoint | Telemetry visible |
| AUD-01 | Audit write | Hash-chain entry |
| AUD-02 | Tamper check | Integrity failure detectable |
| GRAPH-01 | Group membership path | Graph edge visible |
| HYB-01 | Entra users/groups | Live Graph data |
| REC-01 | Recovery readiness | Readiness report |
| PERF-01 | Large test directory | Measure latency/RAM |
