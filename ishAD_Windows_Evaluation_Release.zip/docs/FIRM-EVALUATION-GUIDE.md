# ishAD — Firma Değerlendirme Paketi

## Amaç

Bu paket ishAD'nin gerçek bir Windows/Active Directory ortamında değerlendirilmesi
içindir. İlk çalışma modu **Observe**'dur. Sistem gerçek LDAP/LDAPS verisi okur;
sentetik AD olayı üretmez.

## Ön koşullar

- Windows 10/11 veya Windows Server 2019+
- 64-bit
- Active Directory Domain Controller erişimi
- LDAPS (önerilen) veya kurumun onayladığı LDAP
- Test hesabı
- Test ortamında yeterli audit/event erişimi

## İlk test

1. `ishAD-Windows-Evaluation-Setup.exe` ile kurun.
2. Uygulamayı yönetici yetkisiyle başlatın.
3. Bağlantı ayarlarını kurumun test DC'sine göre girin.
4. Önce **Observe** modunda çalıştırın.
5. İlk baseline'ın oluşmasını bekleyin.
6. AD'de kontrollü, geri alınabilir bir test değişikliği yapın.
7. ishAD'nin değişikliği görmesini, risklendirmesini ve audit kaydı oluşturmasını doğrulayın.
8. Test sonunda audit zincirini ve güvenlik bulgularını dışa aktarın.

## Önerilen kontrollü senaryolar

- Test kullanıcısının bir test grubuna eklenmesi
- Test grubundan çıkarılması
- Test OU'sunda kontrollü attribute değişikliği
- Test hesabının devre dışı bırakılması/açılması
- Test GPO'sunda kontrollü değişiklik
- Yetkisiz/şüpheli SPN veya delegation değişikliği için detection testi
- ACL değişikliği ve exposure analizi
- Kontrollü ağ endpoint/protocol gözlemi

**Domain Admins, Enterprise Admins, Schema Admins veya üretim OU'larında
ilk test yapılmamalıdır.**

## Rollback testi

İlk aşamada otomatik rollback kapalıdır.

Admin onaylı rollback testi yalnızca:
- izole test OU'sunda,
- test hesabında,
- açıkça belgelenmiş before/after state ile,
- değişiklik penceresi sırasında yapılmalıdır.

Silinmiş nesneler için sistem tahmini undelete yapmamalıdır.

## Değerlendirme formu

Firma aşağıdakileri puanlayabilir:

- AD discovery
- Change detection
- Risk scoring
- Approval workflow
- Conflict detection
- Attack-path analysis
- ACL/exposure analysis
- Protocol/network telemetry
- Security event correlation
- Service-account monitoring
- Hybrid/Entra integration
- Audit integrity
- Recovery readiness
- UI usability
- Performance
- Stability
- Deployment

## Başarı kriteri

Test sonucu yalnızca "uygulama açıldı" değildir. Her yetenek için:

**Observed → Evidence → Expected → Actual → Pass/Fail**

şeklinde kayıt tutulmalıdır.
