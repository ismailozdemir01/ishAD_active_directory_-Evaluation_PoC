# Security Notes

- Evaluation release starts in Observe mode.
- Passwords and Graph access tokens are not placed in evaluation.json.
- Destructive operations require explicit administrator approval.
- Delete recovery is not guessed.
- Audit records use a hash-chain integrity mechanism.
- Use a dedicated evaluation account with least privilege.
- Test on a lab domain before production.
- Do not disable TLS certificate validation in production.
