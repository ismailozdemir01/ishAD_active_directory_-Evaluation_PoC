using System.Collections.ObjectModel;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using ishAD.Core.Directory;
using ishAD.Core.Models;
using ishAD.Core.Services;
namespace ishAD.Desktop;
public partial class MainWindow:Window
{
    private readonly IshAdEngine _engine=new();
    private readonly ObservableCollection<AdObject> _objects=new();
    public MainWindow()
    {
        InitializeComponent(); ObjectGrid.ItemsSource=_objects;
        _engine.StatusChanged+=s=>Dispatcher.UIThread.Post(()=>Log(s));
        _engine.ChangeDetected+=c=>Dispatcher.UIThread.Post(()=>{Log($"[{c.RiskLevel}] {c.Operation} — {c.DistinguishedName} — Risk {c.RiskScore}/100");HealthText.Text=$"Health: {Math.Max(0,100-c.RiskScore)}/100";RenderApprovals();});
        _engine.ApprovalChanged+=_=>Dispatcher.UIThread.Post(RenderApprovals);
        _engine.SecurityFindingsUpdated+=f=>Dispatcher.UIThread.Post(()=>Log($"Live security scan: {f.Count} findings; critical={f.Count(x=>x.Severity==\"CRITICAL\")}; high={f.Count(x=>x.Severity==\"HIGH\")}"));
        Log("ishAD hazır. Canlı Active Directory bağlantısı bekleniyor.");
    }
    private async void Connect_Click(object? s,RoutedEventArgs e){await new ConnectionWindow(_engine).ShowDialog(this);if(!string.IsNullOrWhiteSpace(_engine.Settings.BaseDn)){RefreshTree();RefreshObjects();}}
    private void Scan_Click(object? s,RoutedEventArgs e){RefreshObjects();RefreshTree();}
    private void SecurityScan_Click(object? s,RoutedEventArgs e){try{var f=_engine.RefreshLiveSecurity();Log($"Canlı LDAP güvenlik analizi tamamlandı: {f.Count} bulgu.");foreach(var x in f.Where(x=>x.Score>=80).Take(15))Log($"[{x.Severity}] {x.Category}: {x.DistinguishedName} — {x.Evidence}");}catch(Exception ex){Log("Güvenlik analizi hatası: "+ex.Message);}}
    private void RefreshObjects(){try{_objects.Clear();foreach(var o in _engine.GetObjects())_objects.Add(o);Log($"Canlı AD taraması: {_objects.Count} nesne.");}catch(Exception ex){Log("Tarama hatası: "+ex.Message);}}
    private void RefreshTree()
    {
        try
        {
            AdTree.Items.Clear();var entries=_engine.GetTreeEntries();var root=new AdTreeNode(_engine.Settings.BaseDn,_engine.Settings.BaseDn,"Root",new());
            var all=entries.Where(x=>!x.Dn.Equals(_engine.Settings.BaseDn,StringComparison.OrdinalIgnoreCase)).ToDictionary(x=>x.Dn,x=>new AdTreeNode(x.Dn,x.Name,x.Type,new()),StringComparer.OrdinalIgnoreCase);
            foreach(var n in all.Values.OrderBy(x=>x.DistinguishedName.Count(c=>c==',')))
            {var i=n.DistinguishedName.IndexOf(',');var parent=i<0?"":n.DistinguishedName[(i+1)..];if(parent.Equals(_engine.Settings.BaseDn,StringComparison.OrdinalIgnoreCase))root.Children.Add(n);else if(all.TryGetValue(parent,out var p))p.Children.Add(n);}
            AdTree.Items.Add(ToTreeItem(root));
        }catch(Exception ex){Log("Ağaç yükleme hatası: "+ex.Message);}
    }
    private static TreeViewItem ToTreeItem(AdTreeNode n){var i=new TreeViewItem{Header=$"{n.Name} [{n.Type}]"};foreach(var c in n.Children.OrderBy(x=>x.Name))i.Items.Add(ToTreeItem(c));return i;}
    private void RenderApprovals()
    {
        if(_engine.Approvals is null)return;ApprovalPanel.Children.Clear();foreach(var p in _engine.Approvals.Pending())
        {var panel=new StackPanel();panel.Children.Add(new TextBlock{Text="⚠ ONAY BEKLENİYOR",FontWeight=Avalonia.Media.FontWeight.Bold});panel.Children.Add(new TextBlock{Text=p.Plan.DistinguishedName,TextWrapping=Avalonia.Media.TextWrapping.Wrap,Margin=new Thickness(0,5)});panel.Children.Add(new TextBlock{Text=p.Plan.Explanation,TextWrapping=Avalonia.Media.TextWrapping.Wrap});var b=new StackPanel{Orientation=Avalonia.Layout.Orientation.Horizontal};var yes=new Button{Content="GERİ AL",Margin=new Thickness(0,8,5,0)};var no=new Button{Content="KORU",Margin=new Thickness(0,8,0,0)};yes.Click+=(_,_)=>{_engine.Approve(p.Id,Environment.UserName);RenderApprovals();};no.Click+=(_,_)=>{_engine.Reject(p.Id,Environment.UserName);RenderApprovals();};b.Children.Add(yes);b.Children.Add(no);panel.Children.Add(b);ApprovalPanel.Children.Add(new Border{BorderBrush=Avalonia.Media.Brushes.IndianRed,BorderThickness=new Thickness(1),Padding=new Thickness(8),Margin=new Thickness(0,0,0,8),Child=panel});}
    }
    private void Log(string s)=>LogText.Text=$"[{DateTime.Now:HH:mm:ss}] {s}\n"+LogText.Text;
    protected override void OnClosed(EventArgs e){_engine.Dispose();base.OnClosed(e);}
}
