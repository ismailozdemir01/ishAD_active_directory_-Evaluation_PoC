using Avalonia.Controls;
using Avalonia.Interactivity;
using ishAD.Core.Services;
namespace ishAD.Desktop;
public partial class ConnectionWindow:Window
{
    private readonly IshAdEngine _engine;
    public ConnectionWindow(IshAdEngine e){InitializeComponent();_engine=e;}
    private void Connect_Click(object? s,RoutedEventArgs e)
    {
        try
        {
            _engine.Settings.Server=ServerBox.Text??"";
            _engine.Settings.Port=int.TryParse(PortBox.Text,out var p)?p:636;
            _engine.Settings.BaseDn=BaseDnBox.Text??"";
            _engine.Settings.Username=UserBox.Text??"";
            _engine.Settings.UseTls=TlsBox.IsChecked==true;
            _engine.Settings.IgnoreCertificateErrors=IgnoreCertBox.IsChecked==true;
            _engine.Connect(PasswordBox.Text??"");
            StatusText.Text="Bağlantı başarılı.";Close();
        }
        catch(Exception ex){StatusText.Text="Bağlantı başarısız: "+ex.Message;}
    }
}
