using System.Text.Json;
using ishAD.Core.Models;
namespace ishAD.Core.Storage;
public sealed class SnapshotStore
{
    private readonly string _dir=Path.Combine(AppContext.BaseDirectory,"snapshots");
    public SnapshotStore()=>Directory.CreateDirectory(_dir);
    public string Save(IEnumerable<AdObject> objects)
    {
        var id=DateTimeOffset.UtcNow.ToString("yyyyMMdd-HHmmssfff");
        File.WriteAllText(Path.Combine(_dir,id+".json"),
            JsonSerializer.Serialize(objects,new JsonSerializerOptions{WriteIndented=true}));
        return id;
    }
    public IEnumerable<string> List()=>Directory.EnumerateFiles(_dir,"*.json").OrderByDescending(x=>x);
}
