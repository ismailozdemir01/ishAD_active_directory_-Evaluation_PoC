using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.Sqlite;
using ishAD.Core.Models;

namespace ishAD.Core.Storage;

public sealed class AuditStore
{
    private readonly string _db;
    private readonly object _gate = new();

    public AuditStore(string? path = null)
    {
        _db = path ?? Path.Combine(AppContext.BaseDirectory, "ishAD.db");
        Init();
    }

    private SqliteConnection Open()
    {
        var c = new SqliteConnection($"Data Source={_db}");
        c.Open();
        return c;
    }

    private void Init()
    {
        lock (_gate)
        {
            using var c = Open();
            using var x = c.CreateCommand();
            x.CommandText =
                "CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY,type TEXT NOT NULL,dn TEXT,details TEXT NOT NULL,created_utc TEXT NOT NULL,prev_hash TEXT,hash TEXT);" +
                "CREATE TABLE IF NOT EXISTS approvals(id TEXT PRIMARY KEY,change_id TEXT,state TEXT,details TEXT,created_utc TEXT,decision_by TEXT,decision_utc TEXT);";
            x.ExecuteNonQuery();

            TryAlter(c, "ALTER TABLE audit ADD COLUMN prev_hash TEXT");
            TryAlter(c, "ALTER TABLE audit ADD COLUMN hash TEXT");
        }
    }

    private static void TryAlter(SqliteConnection c, string sql)
    {
        try
        {
            using var x = c.CreateCommand();
            x.CommandText = sql;
            x.ExecuteNonQuery();
        }
        catch (SqliteException) { }
    }

    public void Write(string type, string? dn, string details)
    {
        lock (_gate)
        {
            using var c = Open();

            var previous = "";
            using (var q = c.CreateCommand())
            {
                q.CommandText = "SELECT COALESCE(hash,'') FROM audit ORDER BY rowid DESC LIMIT 1";
                previous = q.ExecuteScalar()?.ToString() ?? "";
            }

            var utc = DateTimeOffset.UtcNow.ToString("O");
            var canonical = $"{previous}|{type}|{dn}|{details}|{utc}";
            var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(canonical)));

            using var x = c.CreateCommand();
            x.CommandText =
                "INSERT INTO audit(id,type,dn,details,created_utc,prev_hash,hash) " +
                "VALUES($id,$type,$dn,$details,$utc,$prev,$hash)";
            x.Parameters.AddWithValue("$id", Guid.NewGuid().ToString("N"));
            x.Parameters.AddWithValue("$type", type);
            x.Parameters.AddWithValue("$dn", (object?)dn ?? DBNull.Value);
            x.Parameters.AddWithValue("$details", details);
            x.Parameters.AddWithValue("$utc", utc);
            x.Parameters.AddWithValue("$prev", previous);
            x.Parameters.AddWithValue("$hash", hash);
            x.ExecuteNonQuery();
        }
    }

    public void SaveApproval(ApprovalRequest r)
    {
        lock (_gate)
        using var c = Open();
        using var x = c.CreateCommand();
        x.CommandText =
            "INSERT OR REPLACE INTO approvals VALUES($id,$change,$state,$details,$created,$by,$decision)";
        x.Parameters.AddWithValue("$id", r.Id);
        x.Parameters.AddWithValue("$change", r.ChangeId);
        x.Parameters.AddWithValue("$state", r.State.ToString());
        x.Parameters.AddWithValue("$details", r.Plan.Explanation);
        x.Parameters.AddWithValue("$created", r.CreatedAt.ToString("O"));
        x.Parameters.AddWithValue("$by", (object?)r.DecisionBy ?? DBNull.Value);
        x.Parameters.AddWithValue("$decision", (object?)r.DecisionAt?.ToString("O") ?? DBNull.Value);
        x.ExecuteNonQuery();
    }
}
