namespace ishAD.Core.Storage;
public sealed record AuditEntry(string Id,string Type,string? DistinguishedName,string Details,DateTimeOffset CreatedUtc);
public partial class AuditStore
{
    public IReadOnlyList<AuditEntry> Recent(int limit=200)
    {
        lock(_gate)
        using var c=Open();
        using var x=c.CreateCommand();
        x.CommandText="SELECT id,type,dn,details,created_utc FROM audit ORDER BY created_utc DESC LIMIT $limit";
        x.Parameters.AddWithValue("$limit",Math.Clamp(limit,1,1000));
        using var r=x.ExecuteReader();
        var list=new List<AuditEntry>();
        while(r.Read()) list.Add(new AuditEntry(r.GetString(0),r.GetString(1),
            r.IsDBNull(2)?null:r.GetString(2),r.GetString(3),DateTimeOffset.Parse(r.GetString(4))));
        return list;
    }
}
