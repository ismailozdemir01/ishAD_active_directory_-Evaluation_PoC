using System.DirectoryServices.Protocols;
using System.Net;
using ishAD.Core.Configuration;
namespace ishAD.Core.Directory;
public sealed class AdConnection
{
    private readonly AppSettings _s;
    public AdConnection(AppSettings s)=>_s=s;
    public LdapConnection Create(string password)
    {
        if(string.IsNullOrWhiteSpace(_s.Server)) throw new InvalidOperationException("AD server is not configured.");
        var id=new LdapDirectoryIdentifier(_s.Server,_s.Port,false,false);
        var c=new LdapConnection(id,new NetworkCredential(_s.Username,password),AuthType.Negotiate);
        c.SessionOptions.ProtocolVersion=3;
        c.SessionOptions.ReferralChasing=ReferralChasingOptions.None;
        if(_s.UseTls)c.SessionOptions.SecureSocketLayer=true;
        if(_s.IgnoreCertificateErrors)c.SessionOptions.VerifyServerCertificate=(_,_)=>true;
        c.Bind();
        return c;
    }
}
