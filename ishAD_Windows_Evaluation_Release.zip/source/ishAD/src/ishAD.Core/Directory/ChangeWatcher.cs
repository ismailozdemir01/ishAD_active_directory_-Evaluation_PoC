using System.Text.Json;
using ishAD.Core.Models;

namespace ishAD.Core.Directory;

public sealed class ChangeWatcher : IDisposable
{
    private readonly AdRepository _repo;
    private readonly TimeSpan _delay;
    private readonly Dictionary<string, string> _last = new(StringComparer.OrdinalIgnoreCase);
    private CancellationTokenSource? _cts;
    private Task? _task;
    private long _lastUsn;

    public event Action<AdChange>? ChangeDetected;
    public event Action<string>? Status;

    public ChangeWatcher(AdRepository r, int seconds = 30)
    {
        _repo = r;
        _delay = TimeSpan.FromSeconds(Math.Max(5, seconds));
    }

    public void Start()
    {
        if (_task != null) return;
        _cts = new CancellationTokenSource();
        _task = Task.Run(() => Loop(_cts.Token));
    }

    private async Task Loop(CancellationToken t)
    {
        Status?.Invoke("Live AD watcher started: paged LDAP + uSNChanged cursor + reconciliation.");

        while (!t.IsCancellationRequested)
        {
            try
            {
                var all = _repo.ListObjects();
                var current = all.ToDictionary(
                    x => x.DistinguishedName,
                    Snapshot,
                    StringComparer.OrdinalIgnoreCase);

                var max = all.Select(Usn).Where(x => x > 0).DefaultIfEmpty(_lastUsn).Max();

                if (_last.Count == 0)
                {
                    foreach (var x in current) _last[x.Key] = x.Value;
                    _lastUsn = max;
                    Status?.Invoke($"Initial live baseline: {all.Count} objects; uSNChanged={_lastUsn}");
                }
                else
                {
                    foreach (var x in all)
                    {
                        var snap = Snapshot(x);
                        if (!_last.TryGetValue(x.DistinguishedName, out var old))
                            Emit(x.DistinguishedName, "Create", "", snap);
                        else if (old != snap && Usn(x) >= _lastUsn)
                            Emit(x.DistinguishedName, "Modify", old, snap);
                    }

                    // Reconciliation detects deletions that are no longer returned by LDAP.
                    foreach (var dn in _last.Keys.ToArray())
                        if (!current.ContainsKey(dn))
                            Emit(dn, "Delete", _last[dn], "");

                    _last.Clear();
                    foreach (var x in current) _last[x.Key] = x.Value;
                    _lastUsn = Math.Max(_lastUsn, max);

                    Status?.Invoke(
                        $"Live AD scan: {DateTimeOffset.Now:O} • {all.Count} objects • uSNChanged={_lastUsn}");
                }
            }
            catch (Exception ex)
            {
                Status?.Invoke("Live AD watcher error: " + ex.Message);
            }

            try { await Task.Delay(_delay, t); }
            catch (OperationCanceledException) { }
        }
    }

    private static long Usn(AdObject o) =>
        o.Attributes?.TryGetValue("uSNChanged", out var v) == true &&
        long.TryParse(v.FirstOrDefault(), out var n) ? n : 0;

    private static string Snapshot(AdObject o) =>
        JsonSerializer.Serialize(new { o.ObjectClass, o.WhenChanged, o.Attributes });

    private void Emit(string dn, string op, string before, string after)
    {
        var cls = ExtractClass(before, after);
        ChangeDetected?.Invoke(new AdChange(
            Guid.NewGuid().ToString("N"), dn, cls, op, before, after,
            DateTimeOffset.UtcNow, 0, RiskLevel.Low, false));
    }

    private static string ExtractClass(string before, string after)
    {
        try
        {
            using var d = JsonDocument.Parse(string.IsNullOrWhiteSpace(before) ? after : before);
            return d.RootElement.GetProperty("ObjectClass").GetString() ?? "unknown";
        }
        catch { return "unknown"; }
    }

    public void Dispose()
    {
        _cts?.Cancel();
        try { _task?.Wait(1000); } catch { }
        _cts?.Dispose();
    }
}
