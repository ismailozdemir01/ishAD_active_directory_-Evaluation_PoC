
namespace ishAD.Core.Directory;
public sealed record AdTreeNode(string DistinguishedName,string Name,string Type,List<AdTreeNode> Children);
public static class AdTreeBuilder
{
    public static AdTreeNode Build(string rootDn,IEnumerable<(string Dn,string Name,string Type)> entries)
    {
        var root=new AdTreeNode(rootDn,rootDn,"Root",new());
        var nodes=new Dictionary<string,AdTreeNode>(StringComparer.OrdinalIgnoreCase){{rootDn,root}};
        foreach(var e in entries.OrderBy(x=>x.Dn.Count(c=>c==',')))
        {
            if(e.Dn.Equals(rootDn,StringComparison.OrdinalIgnoreCase)) continue;
            var parent=ParentDn(e.Dn);
            if(!nodes.TryGetValue(parent,out var p)) continue;
            var n=new AdTreeNode(e.Dn,e.Name,e.Type,new());
            p.Children.Add(n); nodes[e.Dn]=n;
        }
        return root;
    }
    private static string ParentDn(string dn){var i=dn.IndexOf(',');return i<0?dn:dn[(i+1)..];}
}
