using System.DirectoryServices.Protocols;
using System.Text;
using ishAD.Core.Models;
namespace ishAD.Core.Directory;
public sealed class AdRepository
{
    private readonly AdConnection _conn; private readonly string _baseDn; private readonly string _password;
    private static readonly string[] InventoryAttrs={"distinguishedName","name","cn","objectClass","whenChanged","uSNChanged","sAMAccountName","userAccountControl","adminCount","member","memberOf","servicePrincipalName","msDS-AllowedToDelegateTo","pwdLastSet","lastLogonTimestamp","description","displayName","primaryGroupID"};
    public string BaseDn=>_baseDn;
    public AdRepository(AdConnection c,string baseDn,string password){_conn=c;_password=password;_baseDn=string.IsNullOrWhiteSpace(baseDn)?ResolveDefaultNamingContext():baseDn;}
    public LdapConnection Open()=>_conn.Create(_password);
    public string ResolveDefaultNamingContext()
    {
        using var ldap=Open();
        var r=(SearchResponse)ldap.SendRequest(new SearchRequest("","(objectClass=*)",SearchScope.Base,new[]{"defaultNamingContext","rootDomainNamingContext","configurationNamingContext"}));
        var e=r.Entries.Count>0?r.Entries[0]:null;
        return e==null?throw new InvalidOperationException("RootDSE did not return naming context."):Str(e,"defaultNamingContext")??throw new InvalidOperationException("defaultNamingContext unavailable.");
    }
    public IReadOnlyList<AdObject> ListObjects(){using var ldap=Open();return SearchObjects(ldap,_baseDn);}
    public IReadOnlyList<AdObject> ListObjects(string filter){using var ldap=Open();return SearchObjects(ldap,_baseDn,filter);}
    public IReadOnlyList<(string Dn,string Name,string Type)> ListContainersAndOUs()
    {
        using var ldap=Open();
        var req=new SearchRequest(_baseDn,"(|(objectClass=organizationalUnit)(objectClass=container)(objectClass=builtinDomain))",SearchScope.Subtree,new[]{"distinguishedName","name","objectClass"});
        var res=Paged(ldap,req); var list=new List<(string,string,string)>();
        foreach(var e in res){var cls=Class(e);list.Add((e.DistinguishedName,Str(e,"name")??e.DistinguishedName,cls));}
        return list;
    }
    public IReadOnlyList<AdObject> ListGroups()=>ListObjects("(objectCategory=group)");
    public IReadOnlyList<AdObject> ListUsers()=>ListObjects("(&(objectCategory=person)(objectClass=user))");
    public IReadOnlyList<AdObject> ListComputers()=>ListObjects("(objectCategory=computer)");
    public IReadOnlyList<AdObject> ListServiceAccounts()=>ListObjects("(&(objectCategory=person)(objectClass=user)(servicePrincipalName=*))");
    public IReadOnlyList<AdObject> ListPrivilegedGroups()=>ListObjects("(|(sAMAccountName=Domain Admins)(sAMAccountName=Enterprise Admins)(sAMAccountName=Administrators)(sAMAccountName=Account Operators)(sAMAccountName=Backup Operators)(sAMAccountName=Server Operators))");
    public bool Exists(string dn)
    {
        using var ldap=Open();
        try { var r=(SearchResponse)ldap.SendRequest(new SearchRequest(dn,"(objectClass=*)",SearchScope.Base,new[]{"distinguishedName","uSNChanged","whenChanged"})); return r.Entries.Count>0; }
        catch(DirectoryOperationException){return false;}
    }
    public AdObject? GetObject(string dn)
    {
        using var ldap=Open();
        var req=new SearchRequest(dn,"(objectClass=*)",SearchScope.Base,InventoryAttrs);
        var r=(SearchResponse)ldap.SendRequest(req); return r.Entries.Count==0?null:ToObject(r.Entries[0]);
    }
    public IReadOnlyList<AdObject> Search(string baseDn,string filter,params string[] attrs){using var ldap=Open();return SearchObjects(ldap,baseDn,filter,attrs);}
    public void AddMember(string groupDn,string memberDn){ModifyMember(groupDn,memberDn,DirectoryAttributeOperation.Add);}
    public void RemoveMember(string groupDn,string memberDn){ModifyMember(groupDn,memberDn,DirectoryAttributeOperation.Delete);}
    public void ReplaceAttribute(string dn,string attribute,IEnumerable<string> values)
    {
        if(string.IsNullOrWhiteSpace(attribute))throw new ArgumentException(nameof(attribute));
        using var l=Open(); var m=new DirectoryAttributeModification{Name=attribute,Operation=DirectoryAttributeOperation.Replace}; foreach(var v in values)m.Add(v); l.SendRequest(new ModifyRequest(dn,m));
    }
    public void SetSingleAttribute(string dn,string attribute,string value)=>ReplaceAttribute(dn,attribute,new[]{value});
    public void ClearAttribute(string dn,string attribute)
    { using var l=Open(); var m=new DirectoryAttributeModification{Name=attribute,Operation=DirectoryAttributeOperation.Delete}; l.SendRequest(new ModifyRequest(dn,m)); }
    private void ModifyMember(string groupDn,string memberDn,DirectoryAttributeOperation op){using var l=Open();var m=new DirectoryAttributeModification{Name="member",Operation=op};m.Add(memberDn);l.SendRequest(new ModifyRequest(groupDn,m));}
    private IReadOnlyList<AdObject> SearchObjects(LdapConnection ldap,string baseDn,string filter="(|(objectClass=user)(objectClass=group)(objectClass=computer)(objectClass=organizationalUnit)(objectClass=container))",string[]? attrs=null)
    {var req=new SearchRequest(baseDn,filter,SearchScope.Subtree,attrs??InventoryAttrs);return Paged(ldap,req).Select(ToObject).ToArray();}
    private static List<SearchResultEntry> Paged(LdapConnection ldap,SearchRequest req)
    {
        req.Controls.Add(new PageResultRequestControl(500)); var all=new List<SearchResultEntry>(); byte[]? cookie=null;
        do {((PageResultRequestControl)req.Controls[0]).Cookie=cookie??Array.Empty<byte>();var res=(SearchResponse)ldap.SendRequest(req);foreach(SearchResultEntry e in res.Entries)all.Add(e);cookie=((PageResultResponseControl)res.Controls.First(x=>x is PageResultResponseControl)).Cookie;} while(cookie is {Length:>0});
        return all;
    }
    private static AdObject ToObject(SearchResultEntry e){var attrs=new Dictionary<string,string[]>(StringComparer.OrdinalIgnoreCase);foreach(string n in e.Attributes.AttributeNames){attrs[n]=e.Attributes[n].GetValues(typeof(string)).Select(x=>x?.ToString()??"").ToArray();}return new(e.DistinguishedName,Str(e,"name")??Str(e,"cn")??e.DistinguishedName,Class(e),Str(e,"whenChanged"),0,attrs);}
    private static string? Str(SearchResultEntry e,string n)=>e.Attributes.Contains(n)&&e.Attributes[n].Count>0?e.Attributes[n][0]?.ToString():null;
    private static string Class(SearchResultEntry e)=>e.Attributes.Contains("objectClass")?e.Attributes["objectClass"].GetValues(typeof(string)).Cast<string>().LastOrDefault()??"unknown":"unknown";
}
