namespace ishAD.Core.Integrations;
public sealed record AlertRoute(string Name,string MinimumSeverity,ISiemSink Sink);
public sealed class AlertRouter
{
    private readonly IReadOnlyList<AlertRoute> _routes; public AlertRouter(IEnumerable<AlertRoute> routes)=>_routes=routes.ToArray();
    public async Task RouteAsync(string severity,string payload,CancellationToken ct=default){foreach(var r in _routes)if(Level(severity)>=Level(r.MinimumSeverity))await r.Sink.SendAsync(payload,ct);}
    private static int Level(string x)=>x.ToLowerInvariant() switch{"low"=>1,"medium"=>2,"high"=>3,"critical"=>4,_=>0};
}
