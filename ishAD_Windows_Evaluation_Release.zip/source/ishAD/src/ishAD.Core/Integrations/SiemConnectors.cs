using System.Net.Sockets;
using System.Text;
namespace ishAD.Core.Integrations;
public interface ISiemSink{Task SendAsync(string payload,CancellationToken ct=default);}
public sealed class SyslogSink:ISiemSink
{
    private readonly string _host;private readonly int _port;public SyslogSink(string host,int port=514){_host=host;_port=port;}
    public async Task SendAsync(string payload,CancellationToken ct=default){using var udp=new UdpClient();var b=Encoding.UTF8.GetBytes(payload);await udp.SendAsync(b,b.Length,_host,_port);}
}
public sealed class WebhookSink:ISiemSink
{
    private readonly HttpClient _http;private readonly Uri _uri;public WebhookSink(Uri uri,HttpClient? http=null){_uri=uri;_http=http??new HttpClient();}
    public async Task SendAsync(string payload,CancellationToken ct=default){using var c=new StringContent(payload,Encoding.UTF8,"application/json");using var r=await _http.PostAsync(_uri,c,ct);r.EnsureSuccessStatusCode();}
}
