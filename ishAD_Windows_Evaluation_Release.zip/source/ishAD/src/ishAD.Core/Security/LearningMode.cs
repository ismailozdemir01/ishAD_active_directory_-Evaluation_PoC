using ishAD.Core.Models;
namespace ishAD.Core.Security;
public sealed class LearningMode
{
    private readonly DateTimeOffset _started=DateTimeOffset.UtcNow;
    private readonly TimeSpan _duration;
    private readonly List<AdChange> _changes=new();
    public LearningMode(TimeSpan? duration=null)=>_duration=duration??TimeSpan.FromHours(1);
    public bool Active=>DateTimeOffset.UtcNow-_started<_duration;
    public TimeSpan Remaining=>Active?_duration-(DateTimeOffset.UtcNow-_started):TimeSpan.Zero;
    public void Observe(AdChange c){lock(_changes)_changes.Add(c);}
    public IReadOnlyList<AdChange> Snapshot(){lock(_changes)return _changes.ToArray();}
}
