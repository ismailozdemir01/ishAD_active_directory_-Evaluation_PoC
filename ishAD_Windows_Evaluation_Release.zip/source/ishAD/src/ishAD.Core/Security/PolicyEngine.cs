using ishAD.Core.Models;

namespace ishAD.Core.Security;

public sealed record PolicyDecision(bool RequireApproval, bool AutoRollbackAllowed, string Reason);

public sealed class PolicyEngine
{
    public PolicyDecision Decide(AdChange c, bool autonomous)
    {
        if (c.Critical)
            return new(true, false, "Critical change requires administrator approval.");

        if (c.RiskLevel == RiskLevel.High)
            return new(true, false, "High-risk change requires administrator approval.");

        if (c.Operation.Equals("Delete", StringComparison.OrdinalIgnoreCase))
            return new(true, false, "Delete recovery is never guessed.");

        if (!c.Operation.Equals("Modify", StringComparison.OrdinalIgnoreCase))
            return new(true, false, "Automatic recovery is limited to verified Modify operations.");

        if (!autonomous)
            return new(true, false, "Autonomous mode is disabled.");

        if (c.RiskLevel == RiskLevel.Medium)
            return new(true, false, "Medium-risk recovery requires administrator approval.");

        return new(false, true, "Verified low-risk rollback may proceed automatically.");
    }
}
