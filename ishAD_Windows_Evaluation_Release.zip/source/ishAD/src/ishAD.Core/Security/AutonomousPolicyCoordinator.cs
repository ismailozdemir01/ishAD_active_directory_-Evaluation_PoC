
using ishAD.Core.Models;
namespace ishAD.Core.Security;
public sealed record AutonomousActionResult(bool Applied,bool ApprovalRequired,bool Conflict,string Reason);
public sealed class AutonomousPolicyCoordinator
{
    private readonly PolicyEngine _policy = new();
    public AutonomousActionResult Evaluate(AdChange change,bool autonomousEnabled,bool learningActive)
    {
        if(learningActive) return new(false,true,false,"Learning mode: observation only.");
        var d=_policy.Decide(change,autonomousEnabled);
        if(d.RequireApproval) return new(false,true,false,d.Reason);
        return new(false,false,false,d.Reason);
    }
}
