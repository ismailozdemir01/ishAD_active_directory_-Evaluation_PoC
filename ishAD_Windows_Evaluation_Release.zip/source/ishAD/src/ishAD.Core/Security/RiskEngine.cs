using ishAD.Core.Models;

namespace ishAD.Core.Security;

public sealed class RiskEngine
{
    public (int score, RiskLevel level, bool critical) Evaluate(
        string cls, string op, string dn, string before, string after)
    {
        var s = 5;

        void Add(int value, bool condition)
        {
            if (condition) s += value;
        }

        Add(45, op.Equals("Delete", StringComparison.OrdinalIgnoreCase));
        Add(20, op.Equals("Create", StringComparison.OrdinalIgnoreCase));
        Add(10, cls.Equals("group", StringComparison.OrdinalIgnoreCase));

        Add(80, ContainsAny(dn, "Domain Admins", "Enterprise Admins", "Schema Admins"));
        Add(70, ContainsAny(after, "Domain Admins", "Enterprise Admins", "Schema Admins"));
        Add(45, ContainsAny(after, "\"adminCount\":[\"1\"]", "adminCount=1"));
        Add(45, ContainsAny(after, "msDS-KeyCredentialLink", "KeyCredential"));
        Add(35, ContainsAny(after, "servicePrincipalName"));
        Add(35, ContainsAny(after, "msDS-AllowedToDelegateTo"));
        Add(35, ContainsAny(after, "sIDHistory"));
        Add(30, ContainsAny(after, "TRUSTED_FOR_DELEGATION"));
        Add(25, ContainsAny(after, "userAccountControl"));
        Add(25, ContainsAny(after, "gPLink"));
        Add(25, ContainsAny(after, "nTSecurityDescriptor"));
        Add(20, ContainsAny(after, "memberOf", "member"));

        // Directory replication / privileged administration signals.
        Add(30, ContainsAny(after, "DCSync", "Replicating Directory Changes"));
        Add(25, ContainsAny(after, "WriteDacl", "GenericAll", "GenericWrite"));
        Add(20, ContainsAny(after, "NTLM", "RC4", "0x17"));

        s = Math.Clamp(s, 0, 100);
        var level = s >= 85 ? RiskLevel.Critical :
                    s >= 65 ? RiskLevel.High :
                    s >= 35 ? RiskLevel.Medium :
                    RiskLevel.Low;

        return (s, level, level == RiskLevel.Critical);
    }

    private static bool ContainsAny(string value, params string[] needles)
        => needles.Any(n => value.Contains(n, StringComparison.OrdinalIgnoreCase));
}
