
using System.Security.Cryptography;
using System.Text;
namespace ishAD.Core.Security;
public sealed class CredentialProtection
{
    public byte[] Protect(string value)
    {
        var bytes=Encoding.UTF8.GetBytes(value);
        return ProtectedData.Protect(bytes,null,DataProtectionScope.CurrentUser);
    }
    public string Unprotect(byte[] value)
    {
        var bytes=ProtectedData.Unprotect(value,null,DataProtectionScope.CurrentUser);
        return Encoding.UTF8.GetString(bytes);
    }
}
