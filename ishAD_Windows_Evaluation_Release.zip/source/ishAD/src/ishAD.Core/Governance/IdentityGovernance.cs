namespace ishAD.Core.Governance;
public sealed record GovernanceFinding(string Control,string Severity,string Subject,string Recommendation);
public sealed class IdentityGovernance
{
    public IReadOnlyList<GovernanceFinding> Evaluate(IEnumerable<dynamic> identities)
    {
        var r=new List<GovernanceFinding>(); foreach(var i in identities){string upn=i.Upn??"";bool enabled=bool.TryParse(i.Enabled?.ToString(),out var b)&&b;if(!enabled)r.Add(new("DisabledIdentity","Low",upn,"Review stale/disabled identity lifecycle"));}return r;
    }
}
