namespace ishAD.Core.Governance;
public sealed record ConditionalAccessFinding(string PolicyId,string Severity,string Issue,string Evidence);
public sealed class ConditionalAccessAnalyzer
{
    public IReadOnlyList<ConditionalAccessFinding> Analyze(IEnumerable<Hybrid.HybridResource> resources)
    {
        var r=new List<ConditionalAccessFinding>(); foreach(var x in resources.Where(x=>x.Type=="Application")){if(x.RawJson.Contains("password",StringComparison.OrdinalIgnoreCase))r.Add(new(x.Id,"Medium","Application sign-in audience or credential posture requires review",x.RawJson));}return r;
    }
}
