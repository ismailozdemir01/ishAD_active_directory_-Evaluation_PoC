using System.Net.Http.Headers;
using System.Text.Json;
namespace ishAD.Core.Hybrid;
public sealed record HybridResource(string Id,string Type,string DisplayName,string? Upn,string RawJson);
public sealed class EntraExpandedGraph
{
    private readonly HttpClient _http; public EntraExpandedGraph(HttpClient? http=null)=>_http=http??new HttpClient{BaseAddress=new Uri("https://graph.microsoft.com/v1.0/")};
    public Task<IReadOnlyList<HybridResource>> Users(string token,CancellationToken ct=default)=>Get("users?$select=id,displayName,userPrincipalName,accountEnabled,createdDateTime,onPremisesSamAccountName,onPremisesSecurityIdentifier",token,"User",ct);
    public Task<IReadOnlyList<HybridResource>> Groups(string token,CancellationToken ct=default)=>Get("groups?$select=id,displayName,securityEnabled,mailEnabled,onPremisesSecurityIdentifier",token,"Group",ct);
    public Task<IReadOnlyList<HybridResource>> Devices(string token,CancellationToken ct=default)=>Get("devices?$select=id,displayName,accountEnabled,operatingSystem,trustType,onPremisesSyncEnabled",token,"Device",ct);
    public Task<IReadOnlyList<HybridResource>> ServicePrincipals(string token,CancellationToken ct=default)=>Get("servicePrincipals?$select=id,displayName,appId,accountEnabled,servicePrincipalType",token,"ServicePrincipal",ct);
    public Task<IReadOnlyList<HybridResource>> Applications(string token,CancellationToken ct=default)=>Get("applications?$select=id,displayName,appId,signInAudience",token,"Application",ct);
    public Task<IReadOnlyList<HybridResource>> DirectoryRoles(string token,CancellationToken ct=default)=>Get("directoryRoles?$select=id,displayName,roleTemplateId",token,"DirectoryRole",ct);
    public Task<IReadOnlyList<HybridResource>> SignIns(string token,CancellationToken ct=default)=>Get("auditLogs/signIns?$top=1000",token,"SignIn",ct);
    private async Task<IReadOnlyList<HybridResource>> Get(string path,string token,string type,CancellationToken ct)
    {
        using var req=new HttpRequestMessage(HttpMethod.Get,path); req.Headers.Authorization=new AuthenticationHeaderValue("Bearer",token); using var res=await _http.SendAsync(req,ct); var body=await res.Content.ReadAsStringAsync(ct); res.EnsureSuccessStatusCode(); using var doc=JsonDocument.Parse(body); var list=new List<HybridResource>(); foreach(var x in doc.RootElement.GetProperty("value").EnumerateArray()){var id=x.TryGetProperty("id",out var i)?i.GetString()??"":"";var dn=x.TryGetProperty("displayName",out var d)?d.GetString()??"":"";var upn=x.TryGetProperty("userPrincipalName",out var u)?u.GetString():null;list.Add(new(id,type,dn,upn,x.ToString()));}return list;
    }
}
