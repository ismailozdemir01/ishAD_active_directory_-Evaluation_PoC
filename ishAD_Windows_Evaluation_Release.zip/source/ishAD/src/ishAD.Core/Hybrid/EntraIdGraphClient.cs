using System.Net.Http.Headers;
using System.Text.Json;

namespace ishAD.Core.Hybrid;

public sealed record EntraObject(
    string Id,
    string DisplayName,
    string Type,
    string UserPrincipalName,
    string AccountEnabled,
    string Source);

/// <summary>
/// Live Microsoft Graph connector. Access tokens are supplied by the caller and
/// are never persisted by ishAD.
/// </summary>
public sealed class EntraIdGraphClient
{
    private readonly HttpClient _http;

    public EntraIdGraphClient(HttpClient? http = null)
        => _http = http ?? new HttpClient
        {
            BaseAddress = new Uri("https://graph.microsoft.com/v1.0/")
        };

    public Task<IReadOnlyList<EntraObject>> ListUsersAsync(
        string accessToken, CancellationToken ct = default)
        => ListAsync("users?$select=id,displayName,userPrincipalName,accountEnabled", "User", accessToken, ct);

    public Task<IReadOnlyList<EntraObject>> ListGroupsAsync(
        string accessToken, CancellationToken ct = default)
        => ListAsync("groups?$select=id,displayName", "Group", accessToken, ct);

    public Task<IReadOnlyList<EntraObject>> ListDevicesAsync(
        string accessToken, CancellationToken ct = default)
        => ListAsync("devices?$select=id,displayName,accountEnabled", "Device", accessToken, ct);

    public Task<IReadOnlyList<EntraObject>> ListServicePrincipalsAsync(
        string accessToken, CancellationToken ct = default)
        => ListAsync("servicePrincipals?$select=id,displayName,appId,accountEnabled", "ServicePrincipal", accessToken, ct);

    public Task<IReadOnlyList<EntraObject>> ListApplicationsAsync(
        string accessToken, CancellationToken ct = default)
        => ListAsync("applications?$select=id,displayName,appId", "Application", accessToken, ct);

    public Task<IReadOnlyList<EntraObject>> ListDirectoryRolesAsync(
        string accessToken, CancellationToken ct = default)
        => ListAsync("roleManagement/directory/roleDefinitions?$select=id,displayName,isBuiltIn", "DirectoryRole", accessToken, ct);

    private async Task<IReadOnlyList<EntraObject>> ListAsync(
        string path, string type, string accessToken, CancellationToken ct)
    {
        var list = new List<EntraObject>();
        var next = path;

        while (!string.IsNullOrWhiteSpace(next))
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, next);
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            using var res = await _http.SendAsync(req, ct);
            var body = await res.Content.ReadAsStringAsync(ct);
            res.EnsureSuccessStatusCode();

            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("value", out var value))
            {
                foreach (var x in value.EnumerateArray())
                {
                    var id = Get(x, "id");
                    var display = Get(x, "displayName");
                    var upn = Get(x, "userPrincipalName");
                    var enabled = x.TryGetProperty("accountEnabled", out var e)
                        ? e.ToString()
                        : "unknown";

                    list.Add(new(id, display, type, upn, enabled, "EntraID"));
                }
            }

            next = doc.RootElement.TryGetProperty("@odata.nextLink", out var n)
                ? n.GetString() ?? ""
                : "";
        }

        return list;
    }

    private static string Get(JsonElement x, string name)
        => x.TryGetProperty(name, out var value) ? value.ToString() : "";
}
