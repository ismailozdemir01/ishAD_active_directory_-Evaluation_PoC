namespace ishAD.Core.Hybrid;
public sealed record HybridRisk(string Key,int Score,string Reason);
public sealed class HybridRiskCorrelation
{
    public IReadOnlyList<HybridRisk> Compare(IEnumerable<HybridResource> ad,IEnumerable<HybridResource> entra)
    {
        var e=entra.Where(x=>!string.IsNullOrWhiteSpace(x.Upn)).GroupBy(x=>x.Upn!,StringComparer.OrdinalIgnoreCase).ToDictionary(x=>x.Key,x=>x.ToList(),StringComparer.OrdinalIgnoreCase); var r=new List<HybridRisk>();
        foreach(var x in ad.Where(x=>!string.IsNullOrWhiteSpace(x.Upn))) if(!e.ContainsKey(x.Upn!)) r.Add(new(x.Upn!,45,"On-prem identity has no matching Entra object"));
        return r;
    }
}
