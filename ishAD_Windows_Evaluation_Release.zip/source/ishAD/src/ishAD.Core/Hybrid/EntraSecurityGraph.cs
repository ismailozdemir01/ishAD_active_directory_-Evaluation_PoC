using System.Net.Http.Headers;
using System.Text.Json;
namespace ishAD.Core.Hybrid;
public sealed record EntraSecurityRecord(string Id,string Type,string DisplayName,string Severity,string RawJson);
public sealed class EntraSecurityGraph
{
    private readonly HttpClient _http; public EntraSecurityGraph(HttpClient? http=null)=>_http=http??new HttpClient{BaseAddress=new Uri("https://graph.microsoft.com/v1.0/")};
    public Task<IReadOnlyList<EntraSecurityRecord>> RiskDetections(string token,CancellationToken ct=default)=>Get("identityProtection/riskDetections?$top=1000",token,"RiskDetection",ct);
    public Task<IReadOnlyList<EntraSecurityRecord>> RiskyUsers(string token,CancellationToken ct=default)=>Get("identityProtection/riskyUsers?$top=1000",token,"RiskyUser",ct);
    public Task<IReadOnlyList<EntraSecurityRecord>> ConditionalAccess(string token,CancellationToken ct=default)=>Get("identity/conditionalAccess/policies?$top=1000",token,"ConditionalAccessPolicy",ct);
    public Task<IReadOnlyList<EntraSecurityRecord>> RoleAssignments(string token,CancellationToken ct=default)=>Get("roleManagement/directory/roleAssignments?$top=1000",token,"RoleAssignment",ct);
    public Task<IReadOnlyList<EntraSecurityRecord>> AdministrativeUnits(string token,CancellationToken ct=default)=>Get("directory/administrativeUnits?$top=1000",token,"AdministrativeUnit",ct);
    public Task<IReadOnlyList<EntraSecurityRecord>> Get(string path,string token,string type,CancellationToken ct=default)=>Fetch(path,token,type,ct);
    private async Task<IReadOnlyList<EntraSecurityRecord>> Fetch(string path,string token,string type,CancellationToken ct)
    {
        var list=new List<EntraSecurityRecord>(); var next=path;
        while(!string.IsNullOrWhiteSpace(next))
        {
            using var req=new HttpRequestMessage(HttpMethod.Get,next);req.Headers.Authorization=new AuthenticationHeaderValue("Bearer",token);using var res=await _http.SendAsync(req,ct);var body=await res.Content.ReadAsStringAsync(ct);res.EnsureSuccessStatusCode();using var doc=JsonDocument.Parse(body);
            if(doc.RootElement.TryGetProperty("value",out var value)) foreach(var x in value.EnumerateArray()){var id=x.TryGetProperty("id",out var i)?i.GetString()??"":"";var dn=x.TryGetProperty("displayName",out var d)?d.GetString()??"":"";var sev=x.TryGetProperty("riskLevel",out var rl)?rl.GetString()??"":"";list.Add(new(id,type,dn,sev,x.ToString()));}
            next=doc.RootElement.TryGetProperty("@odata.nextLink",out var n)?n.GetString()??"":string.Empty;
        }
        return list;
    }
}
