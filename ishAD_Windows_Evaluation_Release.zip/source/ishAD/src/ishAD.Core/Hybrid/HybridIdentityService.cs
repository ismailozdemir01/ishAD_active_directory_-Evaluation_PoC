using ishAD.Core.Directory;

namespace ishAD.Core.Hybrid;

public sealed record HybridIdentityMatch(string AdDn,string AdSam,string? EntraId,string? EntraUpn,double Confidence,string Reason);

public sealed class HybridIdentityService
{
    private readonly AdRepository _ad;
    private readonly EntraIdGraphClient _entra;
    public HybridIdentityService(AdRepository ad, EntraIdGraphClient? entra=null){_ad=ad;_entra=entra??new EntraIdGraphClient();}

    public async Task<IReadOnlyList<HybridIdentityMatch>> CorrelateUsersAsync(string accessToken,CancellationToken ct=default)
    {
        var adUsers=_ad.Search(_ad.BaseDn,"(&(objectCategory=person)(objectClass=user))","distinguishedName","sAMAccountName","userPrincipalName");
        var cloud=await _entra.ListUsersAsync(accessToken,ct);
        var byUpn=cloud.Where(x=>!string.IsNullOrWhiteSpace(x.UserPrincipalName)).ToDictionary(x=>x.UserPrincipalName,StringComparer.OrdinalIgnoreCase);
        var matches=new List<HybridIdentityMatch>();
        foreach(var u in adUsers)
        {
            var sam=Extract(u,"sAMAccountName");
            var upn=Extract(u,"userPrincipalName");
            if(upn is not null && byUpn.TryGetValue(upn,out var e)) matches.Add(new(u.DistinguishedName,sam,e.Id,e.UserPrincipalName,1.0,"Exact userPrincipalName match"));
            else matches.Add(new(u.DistinguishedName,sam,null,null,0,"No verified Entra match"));
        }
        return matches;
    }
    private static string Extract(ishAD.Core.Models.AdObject o,string name) => o.Attributes.TryGetValue(name,out var values) ? values.FirstOrDefault() ?? "" : "";
}
