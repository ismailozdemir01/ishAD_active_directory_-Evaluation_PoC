namespace ishAD.Core.Models;
public enum RiskLevel { Low, Medium, High, Critical }
public enum ApprovalState { Pending, Approved, Rejected, Applied, Conflict, Failed }

public sealed record AdObject(
    string DistinguishedName,string Name,string ObjectClass,string? WhenChanged,int RiskScore,
    IReadOnlyDictionary<string,string[]>? Attributes = null);
public sealed record AdChange(string Id,string DistinguishedName,string ObjectClass,string Operation,string BeforeState,string AfterState,DateTimeOffset DetectedAt,int RiskScore,RiskLevel RiskLevel,bool Critical);
public sealed record RollbackPlan(string ChangeId,string DistinguishedName,string Operation,string BeforeState,string AfterState,string Explanation);
public sealed record ApprovalRequest(string Id,string ChangeId,RollbackPlan Plan,ApprovalState State,DateTimeOffset CreatedAt,string? DecisionBy,DateTimeOffset? DecisionAt);
