using System.Diagnostics;
namespace ishAD.Core.Recovery;
public sealed record ForestHealth(string DcDiag,string Replication,string Dns,string Sysvol,string Fsmo,string SecureChannel);
public sealed class ForestHealthValidation
{
    public ForestHealth Run()
    {
        if(!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException();
        return new(R("dcdiag /test:connectivity"),R("repadmin /replsummary"),R("dcdiag /test:DNS"),R("dcdiag /test:sysvolcheck"),R("netdom query fsmo"),R("nltest /sc_verify"));
    }
    private static string R(string c){var p=new ProcessStartInfo("cmd.exe",$"/c {c}"){RedirectStandardOutput=true,RedirectStandardError=true,UseShellExecute=false,CreateNoWindow=true};using var x=Process.Start(p)!;return x.StandardOutput.ReadToEnd()+x.StandardError.ReadToEnd();}
}
