using System.Diagnostics;
using System.Text.RegularExpressions;
using System.DirectoryServices.Protocols;
using ishAD.Core.Directory;

namespace ishAD.Core.Recovery;

public sealed record BackupPoint(string Version, DateTimeOffset? Created, string Target, bool Parseable);
public sealed record ForestRecoveryReadiness(bool Ready, IReadOnlyList<string> BlockingIssues, IReadOnlyList<string> Warnings, IReadOnlyList<BackupPoint> Backups, DateTimeOffset CheckedAt);
public sealed record ForestRecoveryPlan(string Forest, string RecoveryMode, IReadOnlyList<string> Preconditions, IReadOnlyList<string> Steps, bool DestructiveExecutionAllowed);

/// <summary>
/// Live forest-recovery readiness and runbook generation. It deliberately does not
/// fabricate a restore or perform destructive forest operations. Actual restore is
/// delegated to Microsoft's supported System State/forest-recovery tooling after
/// explicit administrator approval and verified backup media.
/// </summary>
public sealed class ForestRecoveryService
{
    private readonly AdRepository _ad;
    public ForestRecoveryService(AdRepository ad) => _ad = ad;

    public ForestRecoveryReadiness CheckReadiness()
    {
        var blocks = new List<string>();
        var warnings = new List<string>();
        var backups = GetSystemStateBackups();

        if (OperatingSystem.IsWindows())
        {
            if (backups.Count == 0) blocks.Add("No readable System State backup was discovered with wbadmin.");
            if (!HasRecycleBin()) warnings.Add("AD Recycle Bin could not be verified as enabled; deleted-object recovery is more limited.");
        }
        else
        {
            blocks.Add("Forest restore execution requires a Windows domain controller recovery environment.");
        }

        try
        {
            var objects = _ad.Search(_ad.BaseDn, "(objectClass=domainDNS)", "distinguishedName", "dc");
            if (objects.Count == 0) blocks.Add("Domain naming context could not be verified.");
        }
        catch (Exception ex) { blocks.Add("Live AD verification failed: " + ex.Message); }

        return new(blocks.Count == 0, blocks, warnings, backups, DateTimeOffset.UtcNow);
    }

    public ForestRecoveryPlan BuildPlan(string forestName, bool authoritativeRestore)
    {
        var mode = authoritativeRestore ? "Authoritative System State / Forest Recovery" : "Non-authoritative System State / Forest Recovery";
        var pre = new List<string>
        {
            "Verify a known-good System State backup and backup integrity.",
            "Isolate the recovery environment from production until validation completes.",
            "Record current FSMO/domain/forest configuration before recovery.",
            "Confirm DSRM credentials and recovery operator authorization.",
            "Obtain explicit administrator approval before any restore operation."
        };
        var steps = new List<string>
        {
            "Boot the selected domain controller into the supported directory-services recovery workflow.",
            "Restore System State using Microsoft's supported recovery tooling.",
            authoritativeRestore ? "Apply only explicitly approved authoritative objects after validation." : "Allow normal replication to converge after validation.",
            "Validate DNS, SYSVOL, NETLOGON, replication health and FSMO ownership.",
            "Run ishAD post-recovery security scan and compare the recovered baseline.",
            "Keep the environment isolated until all recovery checks pass."
        };
        return new(forestName, mode, pre, steps, false);
    }

    private static IReadOnlyList<BackupPoint> GetSystemStateBackups()
    {
        if (!OperatingSystem.IsWindows()) return Array.Empty<BackupPoint>();
        try
        {
            var psi = new ProcessStartInfo("wbadmin", "get versions")
            {
                RedirectStandardOutput = true, RedirectStandardError = true,
                UseShellExecute = false, CreateNoWindow = true
            };
            using var p = Process.Start(psi);
            if (p is null) return Array.Empty<BackupPoint>();
            var output = p.StandardOutput.ReadToEnd();
            p.WaitForExit(10000);
            var result = new List<BackupPoint>();
            foreach (Match m in Regex.Matches(output, @"Backup time:\s*(?<time>.+)", RegexOptions.IgnoreCase))
            {
                if (DateTimeOffset.TryParse(m.Groups["time"].Value.Trim(), out var dt)) result.Add(new("wbadmin", dt, "System State", true));
            }
            return result;
        }
        catch { return Array.Empty<BackupPoint>(); }
    }

    private bool HasRecycleBin()
    {
        try
        {
            using var ldap = _ad.Open();
            var root = (SearchResponse)ldap.SendRequest(new SearchRequest("", "(objectClass=*)", SearchScope.Base, new[] { "configurationNamingContext" }));
            if (root.Entries.Count == 0 || !root.Entries[0].Attributes.Contains("configurationNamingContext")) return false;
            var config = root.Entries[0].Attributes["configurationNamingContext"][0]?.ToString();
            if (string.IsNullOrWhiteSpace(config)) return false;
            var featureDn = $"CN=Recycle Bin Feature,CN=Optional Features,CN=Directory Service,CN=Windows NT,CN=Services,{config}";
            var forestRoot = (SearchResponse)ldap.SendRequest(new SearchRequest(_ad.BaseDn, "(objectClass=domainDNS)", SearchScope.Base, new[] { "msDS-EnabledFeature" }));
            if (forestRoot.Entries.Count == 0 || !forestRoot.Entries[0].Attributes.Contains("msDS-EnabledFeature")) return false;
            return forestRoot.Entries[0].Attributes["msDS-EnabledFeature"].GetValues(typeof(string)).Cast<string>().Any(x => x.Equals(featureDn, StringComparison.OrdinalIgnoreCase));
        }
        catch { return false; }
    }
}
