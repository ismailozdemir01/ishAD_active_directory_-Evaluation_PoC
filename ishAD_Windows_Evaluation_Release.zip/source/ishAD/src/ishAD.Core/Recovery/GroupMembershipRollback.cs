using ishAD.Core.Directory;
using ishAD.Core.Storage;
namespace ishAD.Core.Recovery;
public sealed class GroupMembershipRollback
{
    private readonly AdRepository _repo; private readonly AuditStore _audit;
    public GroupMembershipRollback(AdRepository repo,AuditStore audit){_repo=repo;_audit=audit;}
    public bool TryRestore(string groupDn,string memberDn,bool shouldBeMember,string admin)
    {
        if(!_repo.Exists(groupDn)||!_repo.Exists(memberDn))
        {
            _audit.Write("RollbackConflict",groupDn,"Group/member missing; manual review required.");
            return false;
        }
        try
        {
            if(shouldBeMember)_repo.AddMember(groupDn,memberDn);
            else _repo.RemoveMember(groupDn,memberDn);
            _audit.Write("RollbackApplied",groupDn,$"member={memberDn}; desired={shouldBeMember}; admin={admin}");
            return true;
        }
        catch(Exception ex){_audit.Write("RollbackFailed",groupDn,ex.Message);return false;}
    }
}
