using System.Diagnostics;
namespace ishAD.Core.Recovery;
public sealed record RecoveryAction(string Id,string Description,string Command,string Risk,string RequiresExplicitApproval);
public sealed class ForestRecoveryExecution
{
    public IReadOnlyList<RecoveryAction> BuildPlan(string backupVersion)
    {
        if(string.IsNullOrWhiteSpace(backupVersion)) throw new ArgumentException("Backup version required",nameof(backupVersion));
        return new[]
        {
            new RecoveryAction("R1","Validate System State backup","wbadmin get versions","Critical","YES"),
            new RecoveryAction("R2","Enter Directory Services Restore Mode on designated DC","DSRM / Safe Mode","Critical","YES"),
            new RecoveryAction("R3","Restore System State using selected backup",$"wbadmin start systemstateRecovery -version:{backupVersion}","Critical","YES"),
            new RecoveryAction("R4","Validate SYSVOL/NETLOGON/DNS/replication","dcdiag /test:DNS && dcdiag /test:sysvolcheck && repadmin /replsummary","High","YES"),
            new RecoveryAction("R5","Validate FSMO and secure channel","netdom query fsmo && nltest /sc_verify","High","YES")
        };
    }
    public string ExecuteReadOnlyCommand(string command)
    {
        if(!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException();
        var allowed=new[]{"wbadmin get versions","dcdiag","repadmin /replsummary","netdom query fsmo","nltest /sc_verify"};
        if(!allowed.Any(x=>command.StartsWith(x,StringComparison.OrdinalIgnoreCase))) throw new InvalidOperationException("Only read-only recovery validation commands are allowed here.");
        var p=new ProcessStartInfo("cmd.exe",$"/c {command}"){RedirectStandardOutput=true,RedirectStandardError=true,UseShellExecute=false,CreateNoWindow=true};
        using var pr=Process.Start(p)??throw new InvalidOperationException("Unable to start command"); return pr.StandardOutput.ReadToEnd()+Environment.NewLine+pr.StandardError.ReadToEnd();
    }
}
