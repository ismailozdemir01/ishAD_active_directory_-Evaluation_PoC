using ishAD.Core.Models;
using ishAD.Core.Security;
using ishAD.Core.Storage;
namespace ishAD.Core.Recovery;
public sealed class ApprovalService
{
    private readonly AuditStore _audit; private readonly Dictionary<string,ApprovalRequest> _pending=new();
    public ApprovalService(AuditStore a)=>_audit=a;
    public event Action<ApprovalRequest>? Changed;
    public ApprovalRequest Create(AdChange c)
    {
        var plan=new RollbackPlan(c.Id,c.DistinguishedName,c.Operation,c.BeforeState,c.AfterState,
            c.Operation=="Delete"?"Deleted-object recovery requires explicit directory-specific recovery.":"Restore the captured previous state using a supported reversible operation.");
        var r=new ApprovalRequest(Guid.NewGuid().ToString("N"),c.Id,plan,ApprovalState.Pending,DateTimeOffset.UtcNow,null,null);
        lock(_pending)_pending[r.Id]=r; _audit.SaveApproval(r); _audit.Write("ApprovalPending",c.DistinguishedName,plan.Explanation); Changed?.Invoke(r); return r;
    }
    public ApprovalRequest Decide(string id,bool approve,string admin)
    {
        lock(_pending)
        {
            if(!_pending.TryGetValue(id,out var r))throw new KeyNotFoundException("Approval not found.");
            r=r with {State=approve?ApprovalState.Approved:ApprovalState.Rejected,DecisionBy=admin,DecisionAt=DateTimeOffset.UtcNow};
            _pending[id]=r; _audit.SaveApproval(r); _audit.Write(approve?"ApprovalGranted":"ApprovalRejected",r.Plan.DistinguishedName,"Decision by "+admin); Changed?.Invoke(r); return r;
        }
    }
    public IReadOnlyCollection<ApprovalRequest> Pending(){lock(_pending)return _pending.Values.Where(x=>x.State==ApprovalState.Pending).ToArray();}
}
