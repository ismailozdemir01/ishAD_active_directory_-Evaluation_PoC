using System.Diagnostics;
namespace ishAD.Core.Recovery;
public sealed record RecoveryEvidence(string Name,string Status,string Output);
public sealed class RecoveryEvidenceCollector
{
    public IReadOnlyList<RecoveryEvidence> Collect()
    {
        if(!OperatingSystem.IsWindows()) return Array.Empty<RecoveryEvidence>();
        return new[]{Run("SystemStateBackups","wbadmin get versions"),Run("Replication","repadmin /replsummary"),Run("DCHealth","dcdiag /test:connectivity"),Run("DNS","dcdiag /test:DNS"),Run("SYSVOL","dcdiag /test:sysvolcheck"),Run("FSMO","netdom query fsmo")};
    }
    private static RecoveryEvidence Run(string n,string c){var p=new ProcessStartInfo("cmd.exe",$"/c {c}"){RedirectStandardOutput=true,RedirectStandardError=true,UseShellExecute=false,CreateNoWindow=true};using var x=Process.Start(p)!;var o=x.StandardOutput.ReadToEnd()+x.StandardError.ReadToEnd();x.WaitForExit();return new(n,x.ExitCode==0?"PASS":"FAIL",o);}
}
