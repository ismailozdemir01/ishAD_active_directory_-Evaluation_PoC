using System.Text.Json;
using ishAD.Core.Directory;
using ishAD.Core.Models;
using ishAD.Core.Storage;
namespace ishAD.Core.Recovery;
public sealed class RollbackExecutor
{
    private readonly AdRepository _repo; private readonly AuditStore _audit;
    private static readonly HashSet<string> SafeAttributes=new(StringComparer.OrdinalIgnoreCase){"description","displayName","userAccountControl","adminCount","servicePrincipalName","msDS-AllowedToDelegateTo"};
    public RollbackExecutor(AdRepository r,AuditStore a){_repo=r;_audit=a;}
    public bool Execute(RollbackPlan p,string admin)
    {
        if(p.Operation.Equals("Delete",StringComparison.OrdinalIgnoreCase)){_audit.Write("RollbackBlocked",p.DistinguishedName,"Deleted-object recovery requires authoritative AD backup/recycle-bin workflow; no guessing.");return false;}
        var current=_repo.GetObject(p.DistinguishedName); if(current==null){_audit.Write("RollbackConflict",p.DistinguishedName,"Target no longer exists.");return false;}
        try
        {
            using var before=JsonDocument.Parse(p.BeforeState); using var after=JsonDocument.Parse(p.AfterState);
            var b=ReadAttrs(before); var a=ReadAttrs(after);
            foreach(var key in a.Keys.Union(b.Keys,StringComparer.OrdinalIgnoreCase))
            { var expected=a.TryGetValue(key,out var ev)?ev:Array.Empty<string>(); var actual=current.Attributes?.TryGetValue(key,out var av)==true?av:Array.Empty<string>(); if(!expected.SequenceEqual(actual,StringComparer.OrdinalIgnoreCase)) { _audit.Write("RollbackConflict",p.DistinguishedName,$"Live AD state differs from approved post-change state for attribute {key}."); return false; } }
            foreach(var attr in SafeAttributes)
            {
                b.TryGetValue(attr,out var bv); a.TryGetValue(attr,out var av); bv??=Array.Empty<string>();av??=Array.Empty<string>();
                if(!bv.SequenceEqual(av,StringComparer.Ordinal)) _repo.ReplaceAttribute(p.DistinguishedName,attr,bv);
            }
            if(b.TryGetValue("member",out var bm)||a.TryGetValue("member",out var am))
            {
                bm??=Array.Empty<string>();am??=Array.Empty<string>();
                foreach(var m in am.Except(bm,StringComparer.OrdinalIgnoreCase))_repo.RemoveMember(p.DistinguishedName,m);
                foreach(var m in bm.Except(am,StringComparer.OrdinalIgnoreCase))_repo.AddMember(p.DistinguishedName,m);
            }
            _audit.Write("RollbackApplied",p.DistinguishedName,$"Approved by {admin}; supported attributes/group membership restored."); return true;
        }catch(Exception ex){_audit.Write("RollbackFailed",p.DistinguishedName,ex.GetType().Name+": "+ex.Message);return false;}
    }
    private static Dictionary<string,string[]> ReadAttrs(JsonDocument d)
    {var r=new Dictionary<string,string[]>(StringComparer.OrdinalIgnoreCase);if(!d.RootElement.TryGetProperty("Attributes",out var a)||a.ValueKind!=JsonValueKind.Object)return r;foreach(var p in a.EnumerateObject())if(p.Value.ValueKind==JsonValueKind.Array)r[p.Name]=p.Value.EnumerateArray().Select(x=>x.GetString()??"").ToArray();return r;}
}
