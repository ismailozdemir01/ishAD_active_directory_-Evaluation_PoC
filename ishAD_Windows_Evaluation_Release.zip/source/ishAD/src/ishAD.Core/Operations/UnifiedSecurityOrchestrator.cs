using ishAD.Core.Detection;using ishAD.Core.Telemetry;using ishAD.Core.Hybrid;
namespace ishAD.Core.Operations;
public sealed record SecuritySnapshot(DateTimeOffset At,IReadOnlyList<SecuritySignal> Signals,IReadOnlyList<ProtocolFinding> ProtocolFindings,IReadOnlyList<TechniqueFinding> Techniques,IReadOnlyList<HybridRisk> HybridRisks);
public sealed class UnifiedSecurityOrchestrator
{
    private readonly AdvancedAttackDetection _events=new(); private readonly LiveNetworkTelemetry _network=new(); private readonly ProtocolSignalCorrelator _protocol=new(); private readonly TechniqueDetectors _techniques=new(); private readonly HybridRiskCorrelation _hybrid=new();
    public SecuritySnapshot Collect(DateTimeOffset since,IEnumerable<HybridResource>? ad=null,IEnumerable<HybridResource>? entra=null)
    {
        var s=_events.Read(since);var n=_network.Snapshot();var p=_protocol.Analyze(n,s);var t=_techniques.Detect(s);var h=ad is null||entra is null?Array.Empty<HybridRisk>():_hybrid.Compare(ad,entra);return new(DateTimeOffset.UtcNow,s,p,t,h);
    }
}
