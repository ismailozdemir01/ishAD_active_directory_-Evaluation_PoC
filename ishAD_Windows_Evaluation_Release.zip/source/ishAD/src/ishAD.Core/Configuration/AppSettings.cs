namespace ishAD.Core.Configuration;
public sealed class AppSettings
{
    public string Server { get; set; } = "";
    public int Port { get; set; } = 636;
    public string BaseDn { get; set; } = "";
    public string Username { get; set; } = "";
    public bool UseTls { get; set; } = true;
    public bool IgnoreCertificateErrors { get; set; }
    public int PollSeconds { get; set; } = 30;
    public string ProtectionMode { get; set; } = "Assisted";
}
