using System.Text.Json;
namespace ishAD.Core.Configuration;
public sealed class SettingsStore
{
    private readonly string _path = Path.Combine(AppContext.BaseDirectory, "ishAD.settings.json");
    public AppSettings Load()
    {
        try { return File.Exists(_path)
            ? JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(_path)) ?? new AppSettings()
            : new AppSettings(); }
        catch { return new AppSettings(); }
    }
    public void Save(AppSettings settings) =>
        File.WriteAllText(_path, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented=true }));
}
