using System.Diagnostics;
using System.Globalization;
using System.Xml.Linq;
using ishAD.Core.Directory;
namespace ishAD.Core.Intelligence;
public sealed record LiveSecurityFinding(string Id,string Category,string Severity,string DistinguishedName,string Evidence,string Recommendation,int Score);
public sealed class LiveSecurityAnalyzer
{
    public IReadOnlyList<LiveSecurityFinding> ScanDirectory(AdRepository repo)
    {
        var f=new List<LiveSecurityFinding>();
        foreach(var g in repo.ListPrivilegedGroups())
        {
            var members=g.Attributes?.TryGetValue("member",out var m)==true?m:Array.Empty<string>();
            foreach(var dn in members)f.Add(new("PRIV-001","Privileged Identity","INFO",dn,$"Member of {g.Name}","Verify business need and delegated scope.",40));
        }
        foreach(var u in repo.ListUsers())
        {
            var a=u.Attributes??new Dictionary<string,string[]>(); var uac=Int(a,"userAccountControl");
            if((uac&0x80000)!=0)f.Add(new("EXP-001","Kerberos","HIGH",u.DistinguishedName,"TRUSTED_FOR_DELEGATION is enabled on a user account.","Remove unconstrained delegation unless explicitly required.",85));
            if((uac&0x400000)!=0)f.Add(new("EXP-002","Kerberos","HIGH",u.DistinguishedName,"Do not require Kerberos pre-authentication is enabled.","Require Kerberos pre-authentication where compatible.",80));
            if(a.ContainsKey("sIDHistory"))f.Add(new("EXP-003","Identity","HIGH",u.DistinguishedName,"SIDHistory attribute is populated.","Validate each SIDHistory value and remove legacy entries when safe.",80));
            if(a.ContainsKey("servicePrincipalName"))f.Add(new("SVC-001","Service Account","MEDIUM",u.DistinguishedName,"User has one or more SPNs.","Use gMSA where possible and monitor service-account behavior.",55));
            if(a.TryGetValue("adminCount",out var ac)&&ac.Any(x=>x=="1"))f.Add(new("PRIV-002","Privilege","HIGH",u.DistinguishedName,"adminCount=1 indicates protected administrative context.","Review privileged group membership and delegation.",75));
            AddStale(f,u,a);
        }
        foreach(var c in repo.ListComputers())
        {
            var a=c.Attributes??new Dictionary<string,string[]>(); var uac=Int(a,"userAccountControl");
            if((uac&0x80000)!=0)f.Add(new("EXP-004","Kerberos","HIGH",c.DistinguishedName,"Computer has unconstrained delegation enabled.","Prefer constrained/resource-based delegation where possible.",85));
            if(a.TryGetValue("msDS-AllowedToDelegateTo",out var targets)&&targets.Length>0)f.Add(new("EXP-005","Delegation","MEDIUM",c.DistinguishedName,$"Constrained delegation targets: {targets.Length}.","Review service targets and privilege boundaries.",60));
        }
        return f;
    }
    public IReadOnlyList<LiveSecurityFinding> ReadWindowsSecurityEvents(TimeSpan lookback)
    {
        if(!OperatingSystem.IsWindows())return new[]{new LiveSecurityFinding("COLLECTOR-001","EventLog","INFO","","Windows Security event collection is only available on Windows.","Run the collector on a domain controller or Windows management host.",0)};
        var since=DateTime.UtcNow.Subtract(lookback); var ids=new[]{4624,4625,4672,4728,4729,4732,4733,4756,4757,4768,4769,4771,5136,5137,5141};
        var q=string.Join(" or ",ids.Select(x=>$"EventID={x}")); var xml=Run("wevtutil",$"qe Security /q:\"*[System[({q}) and TimeCreated[timediff(@SystemTime) <= {Math.Max(1,(int)lookback.TotalMilliseconds)}]]]\" /f:xml /c:500");
        if(string.IsNullOrWhiteSpace(xml))return Array.Empty<LiveSecurityFinding>();
        var result=new List<LiveSecurityFinding>();
        foreach(var block in xml.Split("</Event>",StringSplitOptions.RemoveEmptyEntries))
        {
            var text=block+"</Event>";try{var doc=XDocument.Parse(text);var ev=doc.Descendants("Event").FirstOrDefault();var id=ev?.Descendants("EventID").FirstOrDefault()?.Value??"";var record=ev?.Descendants("EventRecordID").FirstOrDefault()?.Value??"";var level=id switch{"4672"=>"HIGH","4728" or "4732" or "4756"=>"HIGH","5136" or "5137" or "5141"=>"MEDIUM","4625" or "4771"=>"MEDIUM",_=>"INFO"};result.Add(new("EVT-"+id,"Windows Security Event",level,"","EventID="+id+" Record="+record,"Correlate with actor, target and change before remediation.",level=="HIGH"?80:level=="MEDIUM"?50:10));}catch{} }
        return result;
    }
    private static void AddStale(List<LiveSecurityFinding> f,ishAD.Core.Models.AdObject u,Dictionary<string,string[]> a)
    {if(a.TryGetValue("lastLogonTimestamp",out var ll)&&FileTime(ll.FirstOrDefault()) is DateTime last&&last<DateTime.UtcNow.AddDays(-90))f.Add(new("HYGIENE-001","Account Hygiene","MEDIUM",u.DistinguishedName,$"Last logon timestamp is {last:O}.","Review for disablement/removal under your lifecycle policy.",45));}
    private static int Int(Dictionary<string,string[]> a,string n)=>a.TryGetValue(n,out var v)&&int.TryParse(v.FirstOrDefault(),out var x)?x:0;
    private static DateTime? FileTime(string? s){if(long.TryParse(s,out var x)&&x>0)try{return DateTime.FromFileTimeUtc(x);}catch{}return null;}
    private static string Run(string file,string args){try{using var p=Process.Start(new ProcessStartInfo(file,args){RedirectStandardOutput=true,RedirectStandardError=true,UseShellExecute=false,CreateNoWindow=true});if(p==null)return "";var o=p.StandardOutput.ReadToEnd();p.WaitForExit(5000);return o;}catch{return "";}}
}
