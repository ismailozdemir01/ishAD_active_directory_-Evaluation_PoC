using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Text.Json;
using Microsoft.Win32;

namespace ishAD.Core.Intelligence;

public sealed record NetworkSecuritySignal(string Source, string Protocol, string LocalEndpoint, string RemoteEndpoint, string Indicator, int Risk, DateTimeOffset At, IReadOnlyDictionary<string,string> Evidence);

/// <summary>
/// Live defensive telemetry collector. It combines Windows Security/Sysmon event
/// telemetry with active TCP connection metadata and identifies protocol-level AD
/// abuse indicators. It does not inject packets or perform offensive traffic.
/// </summary>
public sealed class ProtocolNetworkDetectionEngine
{
    private static readonly HashSet<int> SecurityIds = new() { 4624,4625,4672,4768,4769,4771,4776,5136,5137,5141 };
    private static readonly int[] AdPorts = {53,88,135,389,445,464,636,3268,3269,9389};

    public IReadOnlyList<NetworkSecuritySignal> CollectLive()
    {
        var signals = new List<NetworkSecuritySignal>();
        signals.AddRange(CollectConnections());
        if (OperatingSystem.IsWindows()) signals.AddRange(CollectEventSignals());
        return signals;
    }

    private static IEnumerable<NetworkSecuritySignal> CollectConnections()
    {
        var now = DateTimeOffset.UtcNow;
        foreach (var c in IPGlobalProperties.GetIPGlobalProperties().GetActiveTcpConnections())
        {
            var remotePort = c.RemoteEndPoint.Port;
            if (!AdPorts.Contains(remotePort)) continue;
            var protocol = remotePort switch
            {
                88 or 464 => "Kerberos",
                389 or 636 or 3268 or 3269 => "LDAP",
                445 => "SMB",
                135 => "RPC",
                53 => "DNS",
                9389 => "ADWS",
                _ => "AD"
            };
            yield return new("ActiveTcp", protocol, c.LocalEndPoint.ToString(), c.RemoteEndPoint.ToString(), "AD service connection observed", 5, now,
                new Dictionary<string,string>{{"state",c.State.ToString()}});
        }
    }

    private static IEnumerable<NetworkSecuritySignal> CollectEventSignals()
    {
        var list = new List<NetworkSecuritySignal>();
        try
        {
            using var p = Process.Start(new ProcessStartInfo("wevtutil", "qe Security /q:*[System[(EventID=4625 or EventID=4672 or EventID=4768 or EventID=4769 or EventID=4771 or EventID=5136 or EventID=5141]]] /f:RenderedXml /c:100")
            { RedirectStandardOutput=true, RedirectStandardError=true, UseShellExecute=false, CreateNoWindow=true });
            if (p is null) return list;
            var xml = p.StandardOutput.ReadToEnd(); p.WaitForExit(10000);
            foreach (var id in SecurityIds)
            {
                var count = CountEvent(xml, id);
                if (count == 0) continue;
                var risk = id switch { 4672 or 5136 or 5141 => 25, 4771 or 4625 => 15, 4768 or 4769 => 10, _ => 5 };
                list.Add(new("WindowsSecurity", ProtocolFor(id), "", "", IndicatorFor(id), Math.Min(100,risk + Math.Min(40,count*2)), DateTimeOffset.UtcNow,
                    new Dictionary<string,string>{{"eventId",id.ToString()},{"count",count.ToString()}}));
            }
        }
        catch { }
        return list;
    }

    private static int CountEvent(string xml, int id) => System.Text.RegularExpressions.Regex.Matches(xml, $"<EventID[^>]*>{id}</EventID>", System.Text.RegularExpressions.RegexOptions.IgnoreCase).Count;
    private static string ProtocolFor(int id) => id switch { 4768 or 4769 or 4771 => "Kerberos", 5136 or 5141 => "LDAP/Directory", 4672 or 4625 => "WindowsLogon", _ => "WindowsSecurity" };
    private static string IndicatorFor(int id) => id switch
    {
        4768 => "Kerberos TGT activity observed",
        4769 => "Kerberos service-ticket activity observed",
        4771 => "Kerberos pre-authentication failure",
        5136 => "Directory object modification",
        5141 => "Directory object deletion",
        4672 => "Special privileges assigned",
        4625 => "Failed logon activity",
        _ => "Security event activity"
    };
}
