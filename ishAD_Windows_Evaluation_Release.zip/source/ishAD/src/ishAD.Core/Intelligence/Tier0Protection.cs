namespace ishAD.Core.Intelligence;
public sealed class Tier0Protection{private static readonly HashSet<string> Names=new(StringComparer.OrdinalIgnoreCase){"Domain Admins","Enterprise Admins","KRBTGT","Domain Controllers"};public bool IsTier0(string name)=>Names.Contains(name);public int Score(string name,bool changed)=>IsTier0(name)?(changed?100:80):0;}
