using System.DirectoryServices;
using System.DirectoryServices.Protocols;
using System.Security.AccessControl;
using System.Security.Principal;
using ishAD.Core.Directory;
namespace ishAD.Core.Intelligence;
public sealed class LiveAclAnalyzer
{
    private static readonly Guid GetChanges=new("1131f6aa-9c07-11d1-f79f-00c04fc2dcd2");
    private static readonly Guid GetChangesAll=new("1131f6ad-9c07-11d1-f79f-00c04fc2dcd2");
    private static readonly Guid GetChangesFiltered=new("89e95b76-444d-4c62-991a-0facbeda640c");
    public IReadOnlyList<LiveSecurityFinding> ScanDomainAcl(AdRepository repo)
    {
        var findings=new List<LiveSecurityFinding>();
        using var ldap=repo.Open();
        var req=new SearchRequest(repo.BaseDn,"(objectClass=*)",SearchScope.Base,new[]{"nTSecurityDescriptor"});
        req.Controls.Add(new SecurityDescriptorFlagControl(SecurityMasks.Dacl));
        var res=(SearchResponse)ldap.SendRequest(req);if(res.Entries.Count==0||!res.Entries[0].Attributes.Contains("nTSecurityDescriptor"))return findings;
        var raw=res.Entries[0].Attributes["nTSecurityDescriptor"][0] as byte[];if(raw==null)return findings;
        var sd=new RawSecurityDescriptor(raw,0);if(sd.DiscretionaryAcl==null)return findings;
        foreach(GenericAce ace in sd.DiscretionaryAcl)
        {
            if(ace is not CommonAce ca||ca.AceType!=AceType.AccessAllowed)continue;
            var sid=ca.SecurityIdentifier.Value;
            if((ca.AccessMask & (int)ActiveDirectoryRights.GenericAll)!=0)
                findings.Add(new("ACL-001","Directory ACL","HIGH",repo.BaseDn,$"GenericAll granted to SID {sid}.","Remove broad control from non-Tier-0 principals.",95));
            if((ca.AccessMask & (int)ActiveDirectoryRights.WriteDacl)!=0)
                findings.Add(new("ACL-002","Directory ACL","HIGH",repo.BaseDn,$"WriteDacl granted to SID {sid}.","Restrict DACL modification to trusted administrative principals.",90));
            if((ca.AccessMask & (int)ActiveDirectoryRights.WriteOwner)!=0)
                findings.Add(new("ACL-003","Directory ACL","HIGH",repo.BaseDn,$"WriteOwner granted to SID {sid}.","Restrict ownership changes to trusted administrative principals.",90));
            if((ca.AccessMask & (int)ActiveDirectoryRights.ExtendedRight)!=0 && ca is ObjectAce oa && (oa.ObjectAceType==GetChanges||oa.ObjectAceType==GetChangesAll||oa.ObjectAceType==GetChangesFiltered))
                findings.Add(new("ACL-004","DCSync Exposure","CRITICAL",repo.BaseDn,$"Replication extended right granted to SID {sid}; ObjectType={oa.ObjectAceType}.","Verify this principal is an authorized replication identity and remove unnecessary replication rights.",100));
        }
        return findings;
    }
}
