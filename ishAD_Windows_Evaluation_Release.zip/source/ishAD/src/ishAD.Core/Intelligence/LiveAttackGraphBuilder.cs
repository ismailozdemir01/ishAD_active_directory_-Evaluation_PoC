using ishAD.Core.Directory;

namespace ishAD.Core.Intelligence;

public sealed class LiveAttackGraphBuilder
{
    public AttackPathGraph Build(AdRepository repo)
    {
        var objects = repo.ListObjects();
        var nodes = new Dictionary<string, GraphNode>(StringComparer.OrdinalIgnoreCase);
        var edges = new List<GraphRelation>();

        foreach (var o in objects)
        {
            var tier0 =
                new Tier0Protection().IsTier0(o.Name) ||
                (o.Attributes?.TryGetValue("adminCount", out var ac) == true &&
                 ac.Any(x => x == "1"));

            nodes[o.DistinguishedName] =
                new(o.DistinguishedName, o.ObjectClass, o.Name, tier0);

            if (o.Attributes?.TryGetValue("member", out var members) == true)
                foreach (var m in members)
                {
                    nodes.TryAdd(m, new(m, "Object", m.Split(',')[0], false));
                    edges.Add(new(m, o.DistinguishedName, "MemberOf"));
                }

            if (o.Attributes?.TryGetValue("memberOf", out var groups) == true)
                foreach (var g in groups)
                {
                    nodes.TryAdd(g, new(g, "Group", g.Split(',')[0], false));
                    edges.Add(new(o.DistinguishedName, g, "MemberOf"));
                }

            if (o.Attributes?.TryGetValue("msDS-AllowedToDelegateTo", out var delegation) == true)
                foreach (var target in delegation)
                    edges.Add(new(o.DistinguishedName, target, "DelegatesTo"));

            if (o.Attributes?.TryGetValue("servicePrincipalName", out var spns) == true)
                foreach (var spn in spns)
                    edges.Add(new(o.DistinguishedName, spn, "HasSPN"));
        }

        var graph = new AttackPathGraph();
        graph.Load(nodes.Values, edges);
        return graph;
    }
}
