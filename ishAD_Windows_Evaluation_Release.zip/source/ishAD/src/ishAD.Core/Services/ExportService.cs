using System.Text.Json;
using ishAD.Core.Storage;
namespace ishAD.Core.Services;
public sealed class ExportService
{
    private readonly AuditStore _audit;
    public ExportService(AuditStore audit)=>_audit=audit;
    public string ExportAudit(string? path=null)
    {
        path ??=Path.Combine(AppContext.BaseDirectory,"exports",$"audit-{DateTimeOffset.UtcNow:yyyyMMdd-HHmmss}.json");
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        File.WriteAllText(path,JsonSerializer.Serialize(_audit.Recent(1000),new JsonSerializerOptions{WriteIndented=true}));
        return path;
    }
}
