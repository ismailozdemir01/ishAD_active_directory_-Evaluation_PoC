namespace ishAD.Core.Services;
public sealed record HealthSnapshot(int Score,int Objects,int PendingApprovals,bool Connected,DateTimeOffset UpdatedUtc);
public sealed class HealthService
{
    public HealthSnapshot Calculate(int objects,int pending,bool connected,int risk)
    {
        var score=connected?100:0;
        score-=Math.Min(60,risk);
        score-=Math.Min(30,pending*10);
        return new(Math.Clamp(score,0,100),objects,pending,connected,DateTimeOffset.UtcNow);
    }
}
