
namespace ishAD.Core.Services;
public sealed class ProtectionState
{
    public ProtectionMode Mode { get; private set; }=ProtectionMode.Monitor;
    public bool LearningCompleted { get; private set; }
    public void SetMode(ProtectionMode mode)=>Mode=mode;
    public void CompleteLearning()=>LearningCompleted=true;
    public bool CanAutoApply=>Mode==ProtectionMode.Autonomous&&LearningCompleted;
}
