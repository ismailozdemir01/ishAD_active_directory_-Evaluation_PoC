using ishAD.Core.Configuration;
using ishAD.Core.Directory;
using ishAD.Core.Detection;
using ishAD.Core.Intelligence;
using ishAD.Core.Models;
using ishAD.Core.Recovery;
using ishAD.Core.Security;
using ishAD.Core.Storage;
using ishAD.Core.Telemetry;

namespace ishAD.Core.Services;

public sealed class IshAdEngine : IDisposable
{
    public AppSettings Settings { get; } = new();
    public AuditStore Audit { get; }
    public ApprovalService Approvals { get; private set; } = null!;

    public LiveSecurityAnalyzer SecurityAnalyzer { get; } = new();
    public LiveAttackGraphBuilder AttackGraphBuilder { get; } = new();
    public LiveAclAnalyzer AclAnalyzer { get; } = new();
    public ProtocolNetworkDetectionEngine ProtocolDetection { get; } = new();
    public AdvancedAttackDetection AttackDetection { get; } = new();
    public LiveNetworkTelemetry NetworkTelemetry { get; } = new();
    public ServiceAccountGuard ServiceAccountGuard { get; } = new();
    public ForestRecoveryReadiness? LastRecoveryReadiness { get; private set; }

    public AttackPathGraph? LiveAttackGraph { get; private set; }
    public AutonomousPolicyCoordinator AutonomousPolicy { get; } = new();

    private ChangeWatcher? _watcher;
    private AdRepository? _repo;
    private CancellationTokenSource? _telemetryCts;
    private Task? _telemetryTask;

    public event Action<AdChange>? ChangeDetected;
    public event Action<string>? StatusChanged;
    public event Action<ApprovalRequest>? ApprovalChanged;
    public event Action<IReadOnlyList<LiveSecurityFinding>>? SecurityFindingsUpdated;

    public IshAdEngine() => Audit = new AuditStore();

    public void Connect(string password)
    {
        var c = new AdConnection(Settings);
        using (c.Create(password)) { }

        _repo = new AdRepository(c, Settings.BaseDn, password);
        Settings.BaseDn = _repo.BaseDn;

        Approvals = new ApprovalService(Audit);
        Approvals.Changed += x => ApprovalChanged?.Invoke(x);

        _watcher = new ChangeWatcher(_repo, Settings.PollSeconds);
        _watcher.ChangeDetected += OnChange;
        _watcher.Status += x => StatusChanged?.Invoke(x);
        _watcher.Start();

        StartLiveTelemetry();
        RefreshLiveSecurity();

        Audit.Write("Connected", Settings.Server,
            $"Live AD connection established. BaseDN={Settings.BaseDn}");
    }

    public IReadOnlyList<AdObject> GetObjects()
        => _repo?.ListObjects() ?? Array.Empty<AdObject>();

    public IReadOnlyList<(string Dn, string Name, string Type)> GetTreeEntries()
        => _repo?.ListContainersAndOUs() ?? Array.Empty<(string, string, string)>();

    public IReadOnlyList<LiveSecurityFinding> RefreshLiveSecurity()
    {
        if (_repo == null) return Array.Empty<LiveSecurityFinding>();

        var findings = SecurityAnalyzer
            .ScanDirectory(_repo)
            .Concat(AclAnalyzer.ScanDomainAcl(_repo))
            .ToArray();

        LiveAttackGraph = AttackGraphBuilder.Build(_repo);

        // Existing service-account guard becomes live: learn current SPN fingerprints,
        // then report unexpected future observations without fabricating activity.
        foreach (var account in _repo.ListServiceAccounts())
        {
            var spns = account.Attributes?.TryGetValue("servicePrincipalName", out var values) == true
                ? values
                : Array.Empty<string>();

            foreach (var spn in spns)
                ServiceAccountGuard.Learn(account.DistinguishedName, spn);
        }

        SecurityFindingsUpdated?.Invoke(findings);

        Audit.Write(
            "SecurityScan",
            Settings.BaseDn,
            $"Live LDAP posture findings={findings.Count}; graphNodes={LiveAttackGraph.Nodes.Count}; graphEdges={LiveAttackGraph.Relations.Count}");

        return findings;
    }

    public IReadOnlyList<LiveSecurityFinding> ReadLiveWindowsSecurityEvents(TimeSpan lookback)
        => SecurityAnalyzer.ReadWindowsSecurityEvents(lookback);

    public IReadOnlyList<NetworkSecuritySignal> ReadLiveProtocolSignals()
        => ProtocolDetection.CollectLive();

    public ForestRecoveryReadiness CheckForestRecoveryReadiness()
    {
        if (_repo == null)
            throw new InvalidOperationException("Connect to AD first.");

        var service = new ForestRecoveryService(_repo);
        LastRecoveryReadiness = service.CheckReadiness();

        Audit.Write(
            "ForestRecoveryReadiness",
            Settings.BaseDn,
            $"Ready={LastRecoveryReadiness.Ready}; backups={LastRecoveryReadiness.Backups.Count}; blocks={LastRecoveryReadiness.BlockingIssues.Count}");

        return LastRecoveryReadiness;
    }

    private void StartLiveTelemetry()
    {
        _telemetryCts?.Cancel();
        _telemetryCts = new CancellationTokenSource();
        var token = _telemetryCts.Token;

        _telemetryTask = Task.Run(async () =>
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    var signals = ProtocolDetection.CollectLive();

                    foreach (var signal in signals.Where(x => x.Risk >= 60))
                    {
                        Audit.Write(
                            "ProtocolSecuritySignal",
                            Settings.BaseDn,
                            $"{signal.Protocol}; {signal.Indicator}; risk={signal.Risk}; {string.Join(";", signal.Evidence.Select(x => x.Key + "=" + x.Value))}");
                    }

                    StatusChanged?.Invoke(
                        $"Live protocol telemetry: {signals.Count} signals; high-risk={signals.Count(x => x.Risk >= 60)}");
                }
                catch (Exception ex)
                {
                    StatusChanged?.Invoke("Protocol telemetry error: " + ex.Message);
                }

                try { await Task.Delay(TimeSpan.FromSeconds(15), token); }
                catch (OperationCanceledException) { }
            }
        }, token);
    }

    private void OnChange(AdChange raw)
    {
        var r = new RiskEngine().Evaluate(
            raw.ObjectClass,
            raw.Operation,
            raw.DistinguishedName,
            raw.BeforeState,
            raw.AfterState);

        var c = raw with
        {
            RiskScore = r.score,
            RiskLevel = r.level,
            Critical = r.critical
        };

        Audit.Write(
            "ChangeDetected",
            c.DistinguishedName,
            $"{c.Operation}; risk={c.RiskScore}; level={c.RiskLevel}");

        ChangeDetected?.Invoke(c);

        var autonomous = Settings.ProtectionMode.Equals(
            "Autonomous", StringComparison.OrdinalIgnoreCase);

        var learning = Settings.ProtectionMode.Equals(
            "Learning", StringComparison.OrdinalIgnoreCase);

        var decision = AutonomousPolicy.Evaluate(c, autonomous, learning);

        if (c.Critical || c.RiskLevel == RiskLevel.High || decision.ApprovalRequired)
        {
            Approvals.Create(c);
        }
        else if (decision.Applied == false &&
                 autonomous &&
                 !decision.ApprovalRequired &&
                 _repo != null)
        {
            var plan = new RollbackPlan(
                c.Id,
                c.DistinguishedName,
                c.Operation,
                c.BeforeState,
                c.AfterState,
                "Policy-approved low-risk autonomous recovery");

            var ok = new RollbackExecutor(_repo, Audit).Execute(plan, "SYSTEM");

            Audit.Write(
                ok ? "AutonomousRollbackApplied" : "AutonomousRollbackFailed",
                c.DistinguishedName,
                decision.Reason);
        }

        _ = Task.Run(RefreshLiveSecurity);
    }

    public void Approve(string id, string admin)
    {
        var r = Approvals.Decide(id, true, admin);
        if (_repo == null) return;

        var current = _repo.GetObject(r.Plan.DistinguishedName);

        if (current == null)
        {
            var conflict = r with { State = ApprovalState.Conflict };
            Audit.SaveApproval(conflict);
            ApprovalChanged?.Invoke(conflict);
            return;
        }

        var ok = new RollbackExecutor(_repo, Audit).Execute(r.Plan, admin);
        var final = r with { State = ok ? ApprovalState.Applied : ApprovalState.Conflict };

        Audit.SaveApproval(final);
        ApprovalChanged?.Invoke(final);

        _ = Task.Run(RefreshLiveSecurity);
    }

    public void Reject(string id, string admin)
        => Approvals.Decide(id, false, admin);

    public void Dispose()
    {
        _telemetryCts?.Cancel();
        try { _telemetryTask?.Wait(1000); } catch { }
        _telemetryCts?.Dispose();
        _watcher?.Dispose();
    }
}
