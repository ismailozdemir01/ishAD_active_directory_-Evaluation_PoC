
using ishAD.Core.Models;
using ishAD.Core.Directory;
namespace ishAD.Core.Services;
public sealed record ConflictResult(bool Safe,string Reason);
public sealed class ConflictGuard
{
    private readonly AdRepository _repo;
    public ConflictGuard(AdRepository repo)=>_repo=repo;
    public ConflictResult Check(AdChange change)
    {
        if(string.IsNullOrWhiteSpace(change.DistinguishedName)) return new(false,"Missing distinguished name.");
        if(!_repo.Exists(change.DistinguishedName)) return new(false,"Target no longer exists; manual review required.");
        return new(true,"Target state still exists.");
    }
}
