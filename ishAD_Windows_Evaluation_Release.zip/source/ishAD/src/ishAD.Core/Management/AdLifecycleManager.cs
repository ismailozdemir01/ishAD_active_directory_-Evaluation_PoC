using ishAD.Core.Directory;
namespace ishAD.Core.Management;
public sealed class AdLifecycleManager
{
    private readonly AdRepository _ad; public AdLifecycleManager(AdRepository ad)=>_ad=ad;
    public void AddGroupMember(string groupDn,string memberDn)=>_ad.AddMember(groupDn,memberDn);
    public void RemoveGroupMember(string groupDn,string memberDn)=>_ad.RemoveMember(groupDn,memberDn);
    public void SetAttribute(string dn,string attribute,string value)=>_ad.SetSingleAttribute(dn,attribute,value);
    public void ClearAttribute(string dn,string attribute)=>_ad.ClearAttribute(dn,attribute);
}
