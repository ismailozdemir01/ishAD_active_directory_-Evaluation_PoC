using System.Diagnostics;
namespace ishAD.Core.Management;
public sealed record GpoOperation(string Action,string Target,string Output,string Success);
public sealed class GpoSecurityManager
{
    public GpoOperation Backup(string path)
    {
        if(!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException(); Directory.CreateDirectory(path); return Run("Get-GPO -All | ForEach-Object { Backup-GPO -Guid $_.Id -Path '"+path.Replace("'","''")+"' }");
    }
    public GpoOperation Report(string path)
    {
        if(!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException(); return Run("Get-GPO -All | Select DisplayName,Id,GpoStatus | ConvertTo-Json -Depth 4");
    }
    private static GpoOperation Run(string command){var p=new ProcessStartInfo("powershell.exe",$"-NoProfile -NonInteractive -Command \"{command}\""){RedirectStandardOutput=true,RedirectStandardError=true,UseShellExecute=false,CreateNoWindow=true};using var x=Process.Start(p)!;var o=x.StandardOutput.ReadToEnd()+x.StandardError.ReadToEnd();x.WaitForExit();return new("PowerShell",command,o,x.ExitCode==0?"true":"false");}
}
