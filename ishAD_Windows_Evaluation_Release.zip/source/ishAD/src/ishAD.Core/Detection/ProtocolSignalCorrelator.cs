using ishAD.Core.Telemetry;

namespace ishAD.Core.Detection;
public sealed record ProtocolFinding(string Category,string Severity,string Description,string Evidence);
public sealed class ProtocolSignalCorrelator
{
    public IReadOnlyList<ProtocolFinding> Analyze(IReadOnlyList<NetworkConnection> c,IReadOnlyList<SecuritySignal> s)
    {
        var f=new List<ProtocolFinding>();
        foreach(var x in c.Where(x=>x.RemotePort is 88 or 389 or 636 or 445 or 135))
            f.Add(new("ADProtocol",x.RemotePort==445?"Medium":"Low",$"{LiveNetworkTelemetry.ClassifyPort(x.RemotePort)} connection observed",x.Raw));
        if(s.Count(x=>x.Technique=="FailedAuthentication")>=10) f.Add(new("BruteForce","High","High volume of failed authentication events",$"count={s.Count(x=>x.Technique=="FailedAuthentication")}"));
        if(s.Any(x=>x.Technique=="PrivilegedGroupMembershipChange") && s.Any(x=>x.Technique=="KerberosActivity")) f.Add(new("PrivilegeCorrelation","Critical","Privileged membership change correlated with Kerberos activity","live Windows Security events"));
        return f;
    }
}
