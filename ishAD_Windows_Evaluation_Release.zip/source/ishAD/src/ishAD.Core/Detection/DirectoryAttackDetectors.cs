namespace ishAD.Core.Detection;
public sealed record DirectoryAttackFinding(string Technique,string Severity,string Subject,string Evidence);
public sealed class DirectoryAttackDetectors
{
    public IReadOnlyList<DirectoryAttackFinding> Detect(IEnumerable<SecuritySignal> signals)
    {
        var s=signals.ToArray();var r=new List<DirectoryAttackFinding>();
        void Add(string tech,string sev,string sub,string ev)=>r.Add(new(tech,sev,sub,ev));
        var priv=s.Where(x=>x.Technique=="PrivilegedGroupMembershipChange").ToArray();
        if(priv.Length>0) Add("PrivilegeEscalation","High",priv[0].Subject,$"{priv.Length} privileged membership changes");
        if(s.Count(x=>x.Technique=="KerberosActivity")>10 && s.Count(x=>x.Technique=="AuthenticationActivity")>10) Add("KerberosLateralMovement","High","Multiple identities","Kerberos + authentication correlation");
        if(s.Any(x=>x.Technique=="DirectoryObjectModification") && s.Any(x=>x.Technique=="DirectoryObjectDeletion")) Add("DirectoryTampering","Critical","Directory","Modification and deletion in same observation window");
        if(s.Count(x=>x.Technique=="NTLMAuthentication")>10) Add("NTLMRelayRisk","Medium","Authentication","Elevated NTLM volume; investigate relay exposure");
        return r;
    }
}
