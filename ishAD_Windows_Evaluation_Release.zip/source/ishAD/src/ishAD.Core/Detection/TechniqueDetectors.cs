namespace ishAD.Core.Detection;
public sealed record TechniqueFinding(string Technique,string Severity,string Rationale,string Evidence);
public sealed class TechniqueDetectors
{
    public IReadOnlyList<TechniqueFinding> Detect(IEnumerable<SecuritySignal> signals)
    {
        var s=signals.ToArray(); var r=new List<TechniqueFinding>();
        if(s.Count(x=>x.Technique=="KerberosActivity")>20) r.Add(new("KerberosAnomaly","High","Elevated Kerberos ticket activity","4768/4769/4771 correlation"));
        if(s.Count(x=>x.Technique=="NTLMAuthentication")>20) r.Add(new("NTLMAnomaly","High","Elevated NTLM authentication activity","4776 correlation"));
        if(s.Any(x=>x.Technique=="DirectoryObjectModification" && x.Evidence.Contains("adminCount",StringComparison.OrdinalIgnoreCase))) r.Add(new("PrivilegedObjectModification","High","Privileged directory object modification observed","5136"));
        if(s.Any(x=>x.Technique=="DirectoryObjectDeletion")) r.Add(new("DirectoryDeletion","High","Directory object deletion observed","5141"));
        return r;
    }
}
