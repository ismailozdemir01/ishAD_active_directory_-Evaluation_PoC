using System.Diagnostics.Eventing.Reader;
using System.Text.RegularExpressions;

namespace ishAD.Core.Detection;

public sealed record SecuritySignal(DateTimeOffset Time, string Source, string Technique, string Severity, string Subject, string Evidence);

/// <summary>Live Windows security-event correlation. No synthetic events are generated.</summary>
public sealed class AdvancedAttackDetection
{
    private static readonly int[] Relevant = {4624,4625,4672,4768,4769,4771,4776,5136,5137,5141,4728,4729,4732,4733,4756,4757};
    public IReadOnlyList<SecuritySignal> Read(DateTimeOffset since, int max=2000)
    {
        if (!OperatingSystem.IsWindows()) return Array.Empty<SecuritySignal>();
        var query = "*[System[(EventID=" + string.Join(" or EventID=", Relevant) + ") and TimeCreated[@SystemTime >= '" + since.UtcDateTime.ToString("o") + "']]]";
        using var reader = new EventLogReader(new EventLogQuery("Security", PathType.LogName, query));
        var result = new List<SecuritySignal>();
        for (EventRecord? e = reader.ReadEvent(); e is not null && result.Count < max; e = reader.ReadEvent())
        {
            using (e)
            {
                var id = e.Id;
                var xml = e.ToXml();
                foreach (var signal in Analyze(id, e.TimeCreated ?? DateTime.Now, xml)) result.Add(signal);
            }
        }
        return result;
    }
    private static IEnumerable<SecuritySignal> Analyze(int id, DateTime time, string xml)
    {
        var t = id switch
        {
            4672 => ("PrivilegedLogon", "High"),
            4728 or 4732 or 4756 => ("PrivilegedGroupMembershipChange", "High"),
            5136 => ("DirectoryObjectModification", "Medium"),
            5137 => ("DirectoryObjectCreation", "Medium"),
            5141 => ("DirectoryObjectDeletion", "High"),
            4768 or 4769 or 4771 => ("KerberosActivity", "Medium"),
            4776 => ("NTLMAuthentication", "Medium"),
            4625 => ("FailedAuthentication", "Medium"),
            _ => ("AuthenticationActivity", "Low")
        };
        var subject = Extract(xml, "TargetUserName") ?? Extract(xml, "SubjectUserName") ?? "unknown";
        var evidence = Regex.Replace(xml, "<EventData>.*?</EventData>", "<EventData>redacted</EventData>", RegexOptions.Singleline);
        yield return new(DateTime.SpecifyKind(time, DateTimeKind.Local), "Windows.Security", t.Item1, t.Item2, subject, evidence);
    }
    private static string? Extract(string xml, string name)
    {
        var m = Regex.Match(xml, $"<Data Name=\\\"{Regex.Escape(name)}\\\">(.*?)</Data>", RegexOptions.Singleline);
        return m.Success ? System.Net.WebUtility.HtmlDecode(m.Groups[1].Value) : null;
    }
}
