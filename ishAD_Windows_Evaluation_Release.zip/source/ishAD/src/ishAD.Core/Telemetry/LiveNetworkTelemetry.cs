using System.Diagnostics;
using System.Net;
using System.Text.Json;

namespace ishAD.Core.Telemetry;

public sealed record NetworkConnection(
    string Protocol,
    string LocalAddress,
    int LocalPort,
    string RemoteAddress,
    int RemotePort,
    string State,
    int? ProcessId,
    string Raw);

public sealed class LiveNetworkTelemetry
{
    public IReadOnlyList<NetworkConnection> Snapshot()
    {
        if (!OperatingSystem.IsWindows()) return Array.Empty<NetworkConnection>();

        var result = new List<NetworkConnection>();
        result.AddRange(ReadTcp());
        result.AddRange(ReadUdp());
        return result;
    }

    private static IEnumerable<NetworkConnection> ReadTcp()
    {
        var p = new ProcessStartInfo(
            "powershell",
            "-NoProfile -NonInteractive -Command \"Get-NetTCPConnection | Select-Object LocalAddress,LocalPort,RemoteAddress,RemotePort,State,OwningProcess | ConvertTo-Json -Compress\"")
        {
            RedirectStandardOutput = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        using var proc = Process.Start(p) ?? throw new InvalidOperationException("PowerShell unavailable");
        var json = proc.StandardOutput.ReadToEnd();
        proc.WaitForExit();

        if (string.IsNullOrWhiteSpace(json)) yield break;

        using var doc = JsonDocument.Parse(json);
        if (doc.RootElement.ValueKind == JsonValueKind.Array)
            foreach (var x in doc.RootElement.EnumerateArray())
                yield return ToConnection(x, "TCP");
        else if (doc.RootElement.ValueKind == JsonValueKind.Object)
            yield return ToConnection(doc.RootElement, "TCP");
    }

    private static IEnumerable<NetworkConnection> ReadUdp()
    {
        var p = new ProcessStartInfo(
            "powershell",
            "-NoProfile -NonInteractive -Command \"Get-NetUDPEndpoint | Select-Object LocalAddress,LocalPort,OwningProcess | ConvertTo-Json -Compress\"")
        {
            RedirectStandardOutput = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        using var proc = Process.Start(p) ?? throw new InvalidOperationException("PowerShell unavailable");
        var json = proc.StandardOutput.ReadToEnd();
        proc.WaitForExit();

        if (string.IsNullOrWhiteSpace(json)) yield break;

        using var doc = JsonDocument.Parse(json);
        if (doc.RootElement.ValueKind == JsonValueKind.Array)
            foreach (var x in doc.RootElement.EnumerateArray())
                yield return new NetworkConnection(
                    "UDP",
                    Get(x, "LocalAddress"),
                    GetInt(x, "LocalPort"),
                    "0.0.0.0",
                    0,
                    "Listening",
                    GetInt(x, "OwningProcess"),
                    x.ToString());
        else if (doc.RootElement.ValueKind == JsonValueKind.Object)
            yield return new NetworkConnection(
                "UDP",
                Get(doc.RootElement, "LocalAddress"),
                GetInt(doc.RootElement, "LocalPort"),
                "0.0.0.0",
                0,
                "Listening",
                GetInt(doc.RootElement, "OwningProcess"),
                doc.RootElement.ToString());
    }

    private static NetworkConnection ToConnection(JsonElement x, string protocol)
        => new(protocol, Get(x, "LocalAddress"), GetInt(x, "LocalPort"),
            Get(x, "RemoteAddress"), GetInt(x, "RemotePort"), Get(x, "State"),
            GetInt(x, "OwningProcess"), x.ToString());

    private static string Get(JsonElement x, string n)
        => x.TryGetProperty(n, out var v) ? v.ToString() : "";

    private static int GetInt(JsonElement x, string n)
        => int.TryParse(Get(x, n), out var i) ? i : 0;

    public static string ClassifyPort(int port) => port switch
    {
        53 => "DNS",
        88 => "Kerberos",
        135 => "RPC",
        389 => "LDAP",
        445 => "SMB",
        464 => "KerberosPassword",
        636 => "LDAPS",
        3268 => "GlobalCatalog",
        3269 => "GlobalCatalogSSL",
        9389 => "ADWebServices",
        _ => "Other"
    };
}
