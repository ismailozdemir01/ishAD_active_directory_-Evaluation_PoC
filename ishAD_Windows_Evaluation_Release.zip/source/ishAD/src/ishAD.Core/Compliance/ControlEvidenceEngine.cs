namespace ishAD.Core.Compliance;
public sealed record ControlEvidence(string Framework,string Control,string Status,string Evidence,string CollectedAt);
public sealed class ControlEvidenceEngine
{
    public IReadOnlyList<ControlEvidence> Build(IEnumerable<(string Name,bool Passed,string Evidence)> checks,string framework="NIST")=>checks.Select(x=>new ControlEvidence(framework,x.Name,x.Passed?"PASS":"FAIL",x.Evidence,DateTimeOffset.UtcNow.ToString("O"))).ToArray();
}
