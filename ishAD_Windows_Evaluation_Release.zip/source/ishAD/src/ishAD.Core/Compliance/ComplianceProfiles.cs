namespace ishAD.Core.Compliance;public sealed class ComplianceProfiles{public IReadOnlyList<string> SupportedFrameworks()=>new[]{"CIS","NIST","ISO27001","SOC2","PCI-DSS","GDPR","HIPAA"};}
