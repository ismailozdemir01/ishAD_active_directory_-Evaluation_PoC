using ishAD.Core.Security;
using Xunit;
namespace ishAD.Tests;
public class RiskEngineTests
{
    [Fact] public void DomainAdminChangeIsCritical()
    {
        var r=new RiskEngine().Evaluate("group","AddToGroup","CN=user01,OU=Users,DC=example,DC=local","x","Domain Admins");
        Assert.True(r.score>=85); Assert.True(r.critical);
    }
    [Fact] public void NormalModifyIsNotCritical()
    {
        var r=new RiskEngine().Evaluate("user","Modify","CN=user01,OU=Users,DC=example,DC=local","x","y");
        Assert.False(r.critical);
    }
}
