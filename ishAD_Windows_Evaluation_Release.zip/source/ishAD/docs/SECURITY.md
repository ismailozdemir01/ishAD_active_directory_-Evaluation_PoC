# Security

- Do not commit AD credentials.
- Prefer LDAPS/StartTLS with certificate validation.
- Use least privilege.
- Critical/high-risk changes require administrator approval.
- Audit detections, approvals, rejections and conflicts.
- Test in an isolated AD lab before production.
- Do not guess deleted-object recovery from incomplete state.
