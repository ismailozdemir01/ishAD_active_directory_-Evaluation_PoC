# ishAD — Final 8 Technical Upgrade Integration

Bu sürümde yeni bağımsız modül eklenmedi. Son sekiz teknik yükseltme, mevcut
ishAD modüllerinin içine derinleştirildi ve birbirine bağlandı.

1. **Protocol / network telemetry**
   - TCP + UDP canlı endpoint görünürlüğü
   - AD/Kerberos/LDAP/SMB/RPC/DNS/ADWS sınıflandırması
   - Windows Security event sinyalleriyle birlikte sürekli collector döngüsü

2. **Detection depth**
   - Kerberos, NTLM, privileged activity, directory modification/deletion
   - delegation, SPN, KeyCredential, SIDHistory, ACL/replication sinyalleri
   - risk seviyesinin policy zincirine girmesi

3. **Incremental AD monitoring**
   - uSNChanged cursor
   - 30 saniyelik varsayılan tarama
   - silinme için reconciliation
   - gerçek LDAP verisi

4. **Attack graph depth**
   - kullanıcı, grup, bilgisayar ve OU nesneleri
   - member/memberOf ilişkileri
   - delegation ve SPN kenarları
   - Tier-0/adminCount sinyalleri

5. **Forest recovery hardening**
   - gerçek System State backup discovery
   - Recycle Bin doğrulaması
   - recovery readiness
   - destructive restore işlemleri explicit admin approval gerektirir

6. **Hybrid identity**
   - Graph pagination
   - users, groups, devices, service principals, applications ve directory roles
   - access token caller-owned; ishAD token saklamaz

7. **Autonomous remediation safety**
   - Critical/High -> approval
   - Delete -> hiçbir zaman tahmini undelete
   - Medium -> approval
   - yalnızca doğrulanmış Low + Modify rollback autonomous
   - canlı state conflict check

8. **Evidence / audit integrity**
   - SQLite audit
   - append-only hash chain
   - approval history
   - recovery/security scan evidence

Bu sekiz alan mevcut FeatureRegistry/Engine/Recovery/Detection/Hybrid/
Telemetry/Storage bileşenleri üzerinden çalışır; bağımsız yeni ürün modülü
oluşturulmamıştır.
