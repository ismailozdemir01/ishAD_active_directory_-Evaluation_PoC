# ishAD Ultimate Feature-Parity Manifest

This release is intended to implement the capability classes identified in the competitor research supplied for Semperis, Microsoft Defender for Identity, Quest, Netwrix, Cayosoft, Tenable, Silverfort, BloodHound and ManageEngine, plus the prior ishAD modules.

## Capability families

- AD/LDAP/LDAPS inventory, paging, tree discovery, change tracking and lifecycle operations
- Real Windows Security Event collection and correlation
- Kerberos/LDAP/SMB/RPC/DNS/ADWS live connection telemetry
- Identity threat detection, privileged activity, failed authentication, directory modification/deletion and group membership monitoring
- Attack technique correlation, lateral-movement indicators, authentication anomalies, NTLM/Kerberos anomalies and directory attack signals
- Attack graph, Tier-0, privileged identity, ACL/exposure, choke-point and path analysis
- Adaptive baseline, risk scoring, posture management and configuration drift
- GPO security inventory, backup/reporting and version tracking
- Approval workflow, dry-run, conflict detection, policy-gated autonomous remediation and audit
- Attribute/group rollback and guarded recovery orchestration
- Forest recovery readiness, System State backup discovery, DCDIAG/REPADMIN/DNS/SYSVOL/FSMO validation and explicit recovery plan generation
- Hybrid AD/Entra inventory, users, groups, devices, service principals, applications, directory roles and sign-in telemetry via Microsoft Graph
- AD/Entra correlation and hybrid risk analysis
- Identity lifecycle/provisioning/governance, service-account controls and MFA/step-up policy hooks
- SIEM/syslog/webhook integration and alert routing
- Compliance evidence and framework mapping
- Dashboard/health/export/snapshot/audit capabilities

## Safety boundary

No proprietary competitor source code is included. Recovery and destructive administrative operations remain policy/approval gated. The implementation uses live sources and never fabricates a successful operation.

## Expanded hybrid security coverage

- Entra Identity Protection risk detections/risky users
- Conditional Access policy inventory
- Directory role assignments
- Administrative units
- Applications and service principals
- Devices and sign-in telemetry
- OData pagination through Microsoft Graph nextLink

## Expanded detection coverage

The live detector consumes Windows Security events and live TCP connection state. It correlates privileged group changes, Kerberos/NTLM authentication, directory modifications/deletions and AD protocol endpoints. It deliberately does not perform exploit traffic or inject packets; detection is evidence-driven.
