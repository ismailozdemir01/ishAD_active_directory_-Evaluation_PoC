# Validation Checklist

The package is source-complete but must be validated in a real Windows/AD lab before production.
The execution environment used to assemble this release does not contain the .NET SDK, so a
local `dotnet build/test` result is not claimed here.

## Required validation

- `dotnet restore`
- `dotnet build -c Release`
- `dotnet test -c Release`
- LDAPS certificate validation
- RootDSE/defaultNamingContext discovery
- Paged inventory with >500 objects
- uSNChanged change detection
- Create/Modify/Delete observation
- Group membership rollback
- Safe attribute rollback
- Live conflict detection after an admin-side change
- Critical/High approval gate
- Autonomous low-risk policy path
- Domain DACL/DCSync finding validation
- Windows Security Event collection on a management host
- Attack graph membership correctness
- GPO/SYSVOL backup/recovery procedures where deployed
- Backup/restore and application data durability

A release is production-ready only after these tests pass against the customer's supported AD
versions and topology.
