# ishAD Final Baseline

Included:
- .NET 8 + Avalonia cross-platform desktop application
- LDAP/LDAPS Active Directory connection
- AD object discovery
- periodic change detection
- risk scoring and critical-change classification
- one-hour learning mode
- monitor / assisted / autonomous policy model
- mandatory administrator approval for high/critical changes
- conflict re-check immediately before recovery
- SQLite audit trail
- approval/rejection history
- local directory snapshots
- supported group-membership rollback adapter
- safe refusal of unsupported delete/undelete guessing
- health score service
- audit export
- Windows and Linux self-contained publishing
- unit tests and operational security documentation

The release deliberately does not fake unsupported AD recovery. Deleted-object
recovery depends on AD Recycle Bin, object state, permissions, domain settings
and retention. Such cases are surfaced for manual review instead of silently
mutating the directory.
