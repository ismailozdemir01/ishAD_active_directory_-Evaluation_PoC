# ishAD Competitive Capability Merge

The following capability families were mapped from the supplied competitor research and implemented as ishAD-native modules. No vendor proprietary code is copied.

## Semperis
- DSP-style change/ITDR
- instant rollback workflow
- posture
- forest recovery orchestration
- clean-room recovery
- Tier-0 exposure
## Microsoft Defender for Identity
- ISPM
- behavioral ITDR
- credential/attack technique detection
- lateral movement paths
- XDR response workflow
## Quest
- Change auditing
- object protection
- Recovery Manager workflow
- GPO version/approval/rollback
- attack-path integration
## Netwrix
- before/after auditing
- logon auditing
- compliance
- threat response
- access mapping
- AD recovery
## Cayosoft
- hybrid monitoring
- object/attribute restore workflow
- forest recovery readiness
- recovery drills
- provisioning/RBAC automation
## Tenable
- IoE/IoA posture
- agentless exposure model
- attack-path analysis
- risk aggregation
## Silverfort
- agentless identity protection
- legacy MFA policy
- service-account behavior
- lateral-movement response
## BloodHound
- collectors/data ingestion
- graph attack paths
- choke points
- Tier-0
- remediation guidance
## ManageEngine
- AD administration
- RBAC/workflow
- hybrid inventory
- real-time audit
- SIEM export
- self-service/MFA policy
- recovery/versioning