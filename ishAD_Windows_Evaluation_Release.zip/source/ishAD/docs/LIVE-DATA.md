# ishAD Live Data Contract

ishAD is not a mock/fixture engine. The production data path is:

1. LDAP/LDAPS bind to the configured Active Directory.
2. RootDSE discovery of `defaultNamingContext` when Base DN is omitted.
3. Paged LDAP inventory for users, groups, computers, OUs and containers.
4. Live attribute reads including `uSNChanged`, `whenChanged`, group membership,
   delegation-related attributes, SPNs, account flags, timestamps and adminCount.
5. Continuous change observation using an AD `uSNChanged` cursor plus reconciliation.
6. Live privileged-membership graph construction.
7. Live posture analysis for delegation, pre-authentication, SIDHistory, SPNs,
   privileged context, stale accounts and domain DACL exposure.
8. Windows Security Event Log collection through `wevtutil` on Windows management hosts.
9. Supported LDAP rollback writes only after policy approval and a fresh state comparison.

No random event generator, fake AD object store, hard-coded test domain, or simulated
successful write is used by these paths.

Intentional limitations are explicit: full forest recovery requires an authoritative,
validated backup/clean-room infrastructure and is not fabricated by ishAD; deleted-object
recovery is not guessed from incomplete snapshots.
