#!/usr/bin/env bash
set -euo pipefail
dotnet restore
dotnet test -c Release
dotnet publish src/ishAD.Desktop/ishAD.Desktop.csproj -c Release -r linux-x64 --self-contained true -p:PublishSingleFile=true -o publish/linux-x64
