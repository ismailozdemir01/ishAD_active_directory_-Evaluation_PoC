$ErrorActionPreference="Stop"
dotnet restore
dotnet test -c Release
dotnet publish src/ishAD.Desktop/ishAD.Desktop.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o publish/win-x64
