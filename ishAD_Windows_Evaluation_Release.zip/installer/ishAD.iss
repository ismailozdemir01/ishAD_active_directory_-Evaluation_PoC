#define MyAppName "ishAD"
#define MyAppVersion "3.0.0"
#define MyAppPublisher "ishAD"
#define MyAppExeName "ishAD.exe"

[Setup]
AppId={{B9A1A1B0-1E17-4B22-AF6D-ISHAD3000}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\ishAD
DefaultGroupName=ishAD
OutputDir=..\dist\installer
OutputBaseFilename=ishAD-Windows-Evaluation-Setup
Compression=lzma
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
DisableProgramGroupPage=yes

[Files]
Source: "..\dist\win-x64\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autodesktop}\ishAD"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\ishAD"; Filename: "{app}\{#MyAppExeName}"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "ishAD'yi başlat"; Flags: nowait postinstall skipifsilent
